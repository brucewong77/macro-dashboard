import { useState } from 'react';
import { useApp, navItems } from '../App';
import { ChevronRight, PanelLeftClose, PanelLeftOpen } from 'lucide-react';

export function Sidebar() {
  const { activeModule, setActiveModule, sidebarCollapsed, setSidebarCollapsed } = useApp();
  const [expandedGroups, setExpandedGroups] = useState<Record<string, boolean>>({
    price: true,
    production: true,
    trade: true,
    consumption: true,
    investment: true,
    finance: true,
    liquidity: true,
  });

  const toggleGroup = (id: string) => {
    setExpandedGroups(prev => ({ ...prev, [id]: !prev[id] }));
  };

  const handleClick = (id: string, hasChildren?: boolean) => {
    if (hasChildren) {
      toggleGroup(id);
    } else {
      setActiveModule(id);
    }
  };

  const isActive = (id: string) => activeModule === id;

  return (
    <aside
      className="flex flex-col bg-[#030712] border-r border-[#1f2937] transition-all duration-300 ease-in-out relative"
      style={{ width: sidebarCollapsed ? 64 : 240 }}
    >
      {/* Header */}
      <div className="flex items-center h-14 px-3 border-b border-[#1f2937] shrink-0">
        {!sidebarCollapsed && (
          <>
            <div className="w-8 h-8 rounded-lg bg-[#3b82f6] flex items-center justify-center mr-3">
              <span className="text-white font-bold text-sm">宏</span>
            </div>
            <span className="font-semibold text-sm text-[#f1f5f9] truncate">宏观经济数据平台</span>
          </>
        )}
        {sidebarCollapsed && (
          <div className="w-8 h-8 rounded-lg bg-[#3b82f6] flex items-center justify-center mx-auto">
            <span className="text-white font-bold text-sm">宏</span>
          </div>
        )}
      </div>

      {/* Toggle button */}
      <button
        onClick={() => setSidebarCollapsed(!sidebarCollapsed)}
        className="absolute -right-3 top-16 w-6 h-6 rounded-full bg-[#1f2937] border border-[#334155] flex items-center justify-center text-[#64748b] hover:text-[#f1f5f9] z-10"
      >
        {sidebarCollapsed ? <PanelLeftOpen size={12} /> : <PanelLeftClose size={12} />}
      </button>

      {/* Navigation */}
      <nav className="flex-1 overflow-y-auto py-2" style={{ scrollbarWidth: 'thin' }}>
        {navItems.map(item => (
          <div key={item.id}>
            {/* Level 1 */}
            <button
              onClick={() => handleClick(item.id, !!item.children)}
              className={`w-full flex items-center h-10 px-3 text-sm transition-colors relative ${
                isActive(item.id) && !item.children
                  ? 'bg-[#1e3a5f] text-[#3b82f6]'
                  : 'text-[#94a3b8] hover:bg-[#0f172a] hover:text-[#f1f5f9]'
              }`}
              title={sidebarCollapsed ? item.label : undefined}
            >
              {isActive(item.id) && !item.children && (
                <div className="absolute left-0 top-0 bottom-0 w-[3px] bg-[#3b82f6]" />
              )}
              {item.icon && (
                <item.icon size={18} className="shrink-0" />
              )}
              {!sidebarCollapsed && (
                <>
                  <span className="ml-3 truncate">{item.label}</span>
                  {item.children && (
                    <ChevronRight
                      size={14}
                      className={`ml-auto text-[#64748b] transition-transform ${
                        expandedGroups[item.id] ? 'rotate-90' : ''
                      }`}
                    />
                  )}
                </>
              )}
            </button>

            {/* Level 2 */}
            {!sidebarCollapsed && item.children && expandedGroups[item.id] && (
              <div className="ml-0">
                {item.children.map(child => (
                  <button
                    key={child.id}
                    onClick={() => setActiveModule(child.id)}
                    className={`w-full flex items-center h-9 pl-9 pr-3 text-[13px] transition-colors relative ${
                      isActive(child.id)
                        ? 'bg-[#1e3a5f] text-[#3b82f6]'
                        : 'text-[#94a3b8] hover:bg-[#0f172a] hover:text-[#f1f5f9]'
                    }`}
                  >
                    {isActive(child.id) && (
                      <div className="absolute left-0 top-0 bottom-0 w-[3px] bg-[#3b82f6]" />
                    )}
                    <span className="truncate">{child.label}</span>
                  </button>
                ))}
              </div>
            )}
          </div>
        ))}
      </nav>
    </aside>
  );
}
