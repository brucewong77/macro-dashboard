import { useApp } from '../App';
import { RefreshCw, Calendar } from 'lucide-react';
import { useState } from 'react';

export function TopBar() {
  const { activeModule, dateRange, setDateRange } = useApp();
  const [refreshing, setRefreshing] = useState(false);

  const moduleNameMap: Record<string, string> = {
    'overview': '数据概览',
    'ppi': 'PPI',
    'cpi': 'CPI',
    'pmi-mfg': '制造业PMI',
    'pmi-nonmfg': '非制造业PMI和财新PMI',
    'industrial': '工业增加值',
    'electricity': '社会用电量',
    'fx-reserve': '外汇储备',
    'export': '出口',
    'import': '进口',
    'retail': '社零增加值',
    'income': '居民可支配收入',
    'unemployment': '城镇失业率',
    'fai': '固定投资增速',
    'realestate': '地产数据',
    'social-financing': '社融',
    'credit': '信贷',
    'policy-rate': '政策利率',
    'money-supply': '资金活力',
    'deposit': '存款',
  };

  const handleRefresh = () => {
    setRefreshing(true);
    setTimeout(() => setRefreshing(false), 1000);
  };

  return (
    <header className="flex items-center justify-between h-14 px-4 bg-[#0a0e1a] border-b border-[#1f2937] shrink-0">
      <div className="flex items-center gap-3">
        <h1 className="text-base font-semibold text-[#f1f5f9]">
          {moduleNameMap[activeModule] || '数据概览'}
        </h1>
      </div>
      <div className="flex items-center gap-3">
        {/* Date Range */}
        <div className="flex items-center gap-2 bg-[#111827] border border-[#1f2937] rounded-lg px-3 py-1.5">
          <Calendar size={14} className="text-[#64748b]" />
          <input
            type="month"
            value={dateRange.start}
            onChange={e => setDateRange({ ...dateRange, start: e.target.value })}
            className="bg-transparent text-xs text-[#f1f5f9] outline-none border-none w-[100px]"
            min="2024-01"
            max="2026-03"
          />
          <span className="text-[#64748b] text-xs">至</span>
          <input
            type="month"
            value={dateRange.end}
            onChange={e => setDateRange({ ...dateRange, end: e.target.value })}
            className="bg-transparent text-xs text-[#f1f5f9] outline-none border-none w-[100px]"
            min="2024-01"
            max="2026-03"
          />
        </div>
        {/* Refresh */}
        <button
          onClick={handleRefresh}
          className="flex items-center justify-center w-8 h-8 rounded-lg bg-[#111827] border border-[#1f2937] text-[#94a3b8] hover:text-[#f1f5f9] hover:border-[#374151] transition-colors"
        >
          <RefreshCw size={14} className={refreshing ? 'animate-spin' : ''} />
        </button>
      </div>
    </header>
  );
}
