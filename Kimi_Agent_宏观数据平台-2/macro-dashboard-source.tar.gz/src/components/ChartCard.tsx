import type { ReactNode } from 'react';
import { Download } from 'lucide-react';

interface ChartCardProps {
  title: string;
  subtitle?: string;
  children: ReactNode;
  className?: string;
}

export function ChartCard({ title, subtitle, children, className = '' }: ChartCardProps) {
  return (
    <div className={`bg-[#111827] border border-[#1f2937] rounded-lg overflow-hidden hover:border-[#374151] transition-colors ${className}`}>
      <div className="flex items-center justify-between px-5 py-3 border-b border-[#1f2937]">
        <div>
          <h3 className="text-sm font-semibold text-[#f1f5f9]">{title}</h3>
          {subtitle && <p className="text-xs text-[#64748b] mt-0.5">{subtitle}</p>}
        </div>
        <button className="text-[#64748b] hover:text-[#f1f5f9] transition-colors p-1 rounded hover:bg-[#1f2937]">
          <Download size={14} />
        </button>
      </div>
      <div className="p-4">
        {children}
      </div>
    </div>
  );
}
