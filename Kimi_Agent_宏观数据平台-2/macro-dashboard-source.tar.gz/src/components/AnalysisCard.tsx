interface AnalysisCardProps {
  title: string;
  content: string;
  updateTime?: string;
}

export function AnalysisCard({ title, content, updateTime }: AnalysisCardProps) {
  return (
    <div className="w-full bg-[#111827] border border-[#1f2937] rounded-lg p-5 relative overflow-hidden hover:border-[#374151] transition-colors">
      <div className="absolute left-0 top-0 bottom-0 w-1 bg-[#3b82f6] rounded-l-lg" />
      <div className="flex items-center justify-between mb-3">
        <h3 className="text-base font-semibold text-[#f1f5f9] flex items-center gap-2">
          <span className="text-[#3b82f6]">📊</span>
          {title}
        </h3>
        {updateTime && (
          <span className="text-xs text-[#64748b]">更新时间: {updateTime}</span>
        )}
      </div>
      <p className="text-sm text-[#94a3b8] leading-relaxed">{content}</p>
    </div>
  );
}
