import { AnalysisCard } from '../components/AnalysisCard';
import { ChartCard } from '../components/ChartCard';
import { pmiData, months } from '../data/economicData';
import ReactECharts from 'echarts-for-react';

const commonOption = {
  backgroundColor: 'transparent',
  tooltip: {
    trigger: 'axis',
    backgroundColor: 'rgba(17,24,39,0.95)',
    borderColor: '#374151',
    textStyle: { color: '#f1f5f9', fontSize: 12 },
  },
  grid: { top: 30, right: 20, bottom: 30, left: 50 },
  xAxis: {
    type: 'category',
    data: months,
    axisLine: { lineStyle: { color: '#334155' } },
    axisLabel: { color: '#64748b', fontSize: 11 },
  },
  yAxis: {
    type: 'value',
    min: 48,
    max: 54,
    axisLine: { lineStyle: { color: '#334155' } },
    splitLine: { lineStyle: { color: '#1e293b', type: 'dashed' } },
    axisLabel: { color: '#64748b', fontSize: 11 },
  },
};

export function PMINonManufacturingModule() {
  const nonMfgOption = {
    ...commonOption,
    legend: { data: ['非制造业PMI'], top: 0, right: 0, textStyle: { color: '#94a3b8', fontSize: 11 } },
    series: [
      { name: '非制造业PMI', type: 'line', data: pmiData.nonManufacturing.map(d => d.value), lineStyle: { color: '#3b82f6', width: 2 }, itemStyle: { color: '#3b82f6' }, symbol: 'circle', symbolSize: 4 },
      { name: '荣枯线', type: 'line', data: months.map(() => 50), lineStyle: { color: '#64748b', width: 1, type: 'dashed' }, itemStyle: { color: '#64748b' }, symbol: 'none' },
    ],
  };

  const caixinOption = {
    ...commonOption,
    legend: { data: ['财新PMI', '官方制造业PMI'], top: 0, right: 0, textStyle: { color: '#94a3b8', fontSize: 11 } },
    series: [
      { name: '财新PMI', type: 'line', data: pmiData.caixin.map(d => d.value), lineStyle: { color: '#f59e0b', width: 2 }, itemStyle: { color: '#f59e0b' }, symbol: 'circle', symbolSize: 4 },
      { name: '官方制造业PMI', type: 'line', data: pmiData.manufacturing['2025'].slice(12).concat(pmiData.manufacturing['2026'].slice(24)).filter(v => v !== 0), lineStyle: { color: '#3b82f6', width: 2 }, itemStyle: { color: '#3b82f6' }, symbol: 'circle', symbolSize: 4 },
      { name: '荣枯线', type: 'line', data: months.map(() => 50), lineStyle: { color: '#64748b', width: 1, type: 'dashed' }, itemStyle: { color: '#64748b' }, symbol: 'none' },
    ],
  };

  return (
    <div className="space-y-4">
      <AnalysisCard title="最新非制造业PMI与财新PMI数据解读" content="2026年4月，非制造业PMI为51.5%，比上月回落0.5个百分点但仍处于扩张区间。商务活动指数52.0%，新订单指数50.8%。财新PMI为50.9%，低于官方制造业PMI的49.8%，两者走势分化主要源于样本企业差异——财新样本更偏出口导向型中小企业。" updateTime="2026-04-30" />
      <div className="grid grid-cols-2 gap-4">
        <ChartCard title="非制造业 PMI" subtitle="2024.01-2026.03">
          <ReactECharts option={nonMfgOption} style={{ height: 300 }} />
        </ChartCard>
        <ChartCard title="财新 PMI" subtitle="2024.01-2026.03">
          <ReactECharts option={caixinOption} style={{ height: 300 }} />
        </ChartCard>
      </div>
    </div>
  );
}
