import { AnalysisCard } from '../components/AnalysisCard';
import { ChartCard } from '../components/ChartCard';
import { electricityData, months } from '../data/economicData';
import ReactECharts from 'echarts-for-react';

export function ElectricityModule() {
  const totalOption = {
    backgroundColor: 'transparent',
    tooltip: {
      trigger: 'axis',
      backgroundColor: 'rgba(17,24,39,0.95)',
      borderColor: '#374151',
      textStyle: { color: '#f1f5f9', fontSize: 12 },
    },
    grid: { top: 30, right: 50, bottom: 30, left: 60 },
    legend: { data: ['全社会用电量(亿千瓦时)', '同比增速'], top: 0, right: 0, textStyle: { color: '#94a3b8', fontSize: 10 } },
    xAxis: {
      type: 'category',
      data: months,
      axisLine: { lineStyle: { color: '#334155' } },
      axisLabel: { color: '#64748b', fontSize: 11 },
    },
    yAxis: [
      { type: 'value', axisLine: { lineStyle: { color: '#334155' } }, splitLine: { lineStyle: { color: '#1e293b', type: 'dashed' } }, axisLabel: { color: '#64748b', fontSize: 11 } },
      { type: 'value', axisLine: { lineStyle: { color: '#334155' } }, splitLine: { show: false }, axisLabel: { color: '#64748b', fontSize: 11, formatter: '{value}%' } },
    ],
    series: [
      { name: '全社会用电量(亿千瓦时)', type: 'bar', data: electricityData.total.map(d => d.value), itemStyle: { color: '#3b82f6', borderRadius: 2 }, barWidth: '50%', yAxisIndex: 0 },
      { name: '同比增速', type: 'line', data: electricityData.yoy.map(d => d.value), lineStyle: { color: '#ef4444', width: 2 }, itemStyle: { color: '#ef4444' }, symbol: 'circle', symbolSize: 4, yAxisIndex: 1 },
    ],
  };

  const byIndustryOption = {
    backgroundColor: 'transparent',
    tooltip: {
      trigger: 'axis',
      backgroundColor: 'rgba(17,24,39,0.95)',
      borderColor: '#374151',
      textStyle: { color: '#f1f5f9', fontSize: 12 },
    },
    legend: { data: ['第一产业', '第二产业', '第三产业'], top: 0, right: 0, textStyle: { color: '#94a3b8', fontSize: 10 } },
    grid: { top: 30, right: 20, bottom: 30, left: 50 },
    xAxis: {
      type: 'category',
      data: months,
      axisLine: { lineStyle: { color: '#334155' } },
      axisLabel: { color: '#64748b', fontSize: 11 },
    },
    yAxis: {
      type: 'value',
      axisLine: { lineStyle: { color: '#334155' } },
      splitLine: { lineStyle: { color: '#1e293b', type: 'dashed' } },
      axisLabel: { color: '#64748b', fontSize: 11, formatter: '{value}%' },
    },
    series: [
      { name: '第一产业', type: 'bar', data: electricityData.byIndustry.primary.map(d => d.value), itemStyle: { color: '#22c55e' }, barWidth: '20%' },
      { name: '第二产业', type: 'bar', data: electricityData.byIndustry.secondary.map(d => d.value), itemStyle: { color: '#3b82f6' }, barWidth: '20%' },
      { name: '第三产业', type: 'bar', data: electricityData.byIndustry.tertiary.map(d => d.value), itemStyle: { color: '#f59e0b' }, barWidth: '20%' },
    ],
  };

  return (
    <div className="space-y-4">
      <AnalysisCard title="最新社会用电量数据解读" content={electricityData.analysis} updateTime="2026-04-15" />
      <div className="grid grid-cols-2 gap-4">
        <ChartCard title="全社会用电量及同比增速" subtitle="2024.01-2026.03">
          <ReactECharts option={totalOption} style={{ height: 300 }} />
        </ChartCard>
        <ChartCard title="分产业用电量当月同比" subtitle="2024.01-2026.03">
          <ReactECharts option={byIndustryOption} style={{ height: 300 }} />
        </ChartCard>
      </div>
    </div>
  );
}
