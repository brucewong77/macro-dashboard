import { AnalysisCard } from '../components/AnalysisCard';
import { ChartCard } from '../components/ChartCard';
import { depositData, months } from '../data/economicData';
import ReactECharts from 'echarts-for-react';

const commonOption = {
  backgroundColor: 'transparent',
  tooltip: {
    trigger: 'axis',
    axisPointer: { type: 'shadow' },
    backgroundColor: 'rgba(17,24,39,0.95)',
    borderColor: '#374151',
    textStyle: { color: '#f1f5f9', fontSize: 12 },
  },
  grid: { top: 30, right: 20, bottom: 30, left: 50 },
  xAxis: {
    type: 'category',
    data: months,
    axisLine: { lineStyle: { color: '#334155' } },
    axisLabel: { color: '#64748b', fontSize: 11 },
  },
};

export function DepositModule() {
  const monthlyOption = {
    ...commonOption,
    legend: { data: ['居民存款', '财政存款', '非金融企业', '非银金融'], top: 0, right: 0, textStyle: { color: '#94a3b8', fontSize: 10 } },
    yAxis: {
      type: 'value',
      axisLine: { lineStyle: { color: '#334155' } },
      splitLine: { lineStyle: { color: '#1e293b', type: 'dashed' } },
      axisLabel: { color: '#64748b', fontSize: 11, formatter: '{value}万亿' },
    },
    series: [
      { name: '居民存款', type: 'bar', data: depositData.household.map(d => d.value), itemStyle: { color: '#3b82f6' }, barWidth: '20%' },
      { name: '财政存款', type: 'bar', data: depositData.fiscal.map(d => d.value), itemStyle: { color: '#22c55e' }, barWidth: '20%' },
      { name: '非金融企业', type: 'bar', data: depositData.enterprise.map(d => d.value), itemStyle: { color: '#f59e0b' }, barWidth: '20%' },
      { name: '非银金融', type: 'bar', data: depositData.nonBank.map(d => d.value), itemStyle: { color: '#ef4444' }, barWidth: '20%' },
    ],
  };

  const accumOption = {
    ...commonOption,
    legend: { data: ['居民存款', '财政存款', '非金融企业', '非银金融'], top: 0, right: 0, textStyle: { color: '#94a3b8', fontSize: 10 } },
    yAxis: {
      type: 'value',
      axisLine: { lineStyle: { color: '#334155' } },
      splitLine: { lineStyle: { color: '#1e293b', type: 'dashed' } },
      axisLabel: { color: '#64748b', fontSize: 11, formatter: '{value}万亿' },
    },
    series: [
      { name: '居民存款', type: 'line', data: depositData.accumHousehold, lineStyle: { color: '#3b82f6', width: 2 }, itemStyle: { color: '#3b82f6' }, symbol: 'circle', symbolSize: 3 },
      { name: '财政存款', type: 'line', data: depositData.accumFiscal, lineStyle: { color: '#22c55e', width: 2 }, itemStyle: { color: '#22c55e' }, symbol: 'circle', symbolSize: 3 },
      { name: '非金融企业', type: 'line', data: depositData.accumEnterprise, lineStyle: { color: '#f59e0b', width: 2 }, itemStyle: { color: '#f59e0b' }, symbol: 'circle', symbolSize: 3 },
      { name: '非银金融', type: 'line', data: depositData.accumNonBank, lineStyle: { color: '#ef4444', width: 2 }, itemStyle: { color: '#ef4444' }, symbol: 'circle', symbolSize: 3 },
    ],
  };

  return (
    <div className="space-y-4">
      <AnalysisCard title="最新存款数据解读" content={depositData.analysis} updateTime="2026-04-15" />
      <div className="grid grid-cols-2 gap-4">
        <ChartCard title="各类存款当月值" subtitle="万亿元">
          <ReactECharts option={monthlyOption} style={{ height: 300 }} />
        </ChartCard>
        <ChartCard title="各类存款当年累计值" subtitle="万亿元">
          <ReactECharts option={accumOption} style={{ height: 300 }} />
        </ChartCard>
      </div>
    </div>
  );
}
