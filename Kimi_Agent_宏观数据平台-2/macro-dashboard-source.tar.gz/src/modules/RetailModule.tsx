import { AnalysisCard } from '../components/AnalysisCard';
import { ChartCard } from '../components/ChartCard';
import { retailData, months } from '../data/economicData';
import ReactECharts from 'echarts-for-react';

export function RetailModule() {
  const yoyOption = {
    backgroundColor: 'transparent',
    tooltip: {
      trigger: 'axis',
      backgroundColor: 'rgba(17,24,39,0.95)',
      borderColor: '#374151',
      textStyle: { color: '#f1f5f9', fontSize: 12 },
    },
    grid: { top: 30, right: 20, bottom: 30, left: 50 },
    xAxis: {
      type: 'category',
      data: months,
      axisLine: { lineStyle: { color: '#334155' } },
      axisLabel: { color: '#64748b', fontSize: 11 },
    },
    yAxis: {
      type: 'value',
      axisLine: { lineStyle: { color: '#334155' } },
      splitLine: { lineStyle: { color: '#1e293b', type: 'dashed' } },
      axisLabel: { color: '#64748b', fontSize: 11, formatter: '{value}%' },
    },
    series: [{
      type: 'line',
      data: retailData.yoy.map(d => d.value),
      lineStyle: { color: '#f59e0b', width: 2 },
      itemStyle: { color: '#f59e0b' },
      symbol: 'circle',
      symbolSize: 4,
      areaStyle: {
        color: { type: 'linear', x: 0, y: 0, x2: 0, y2: 1, colorStops: [
          { offset: 0, color: 'rgba(245,158,11,0.15)' },
          { offset: 1, color: 'rgba(245,158,11,0)' },
        ]},
      },
    }],
  };

  const industryOption = {
    backgroundColor: 'transparent',
    tooltip: {
      trigger: 'axis',
      axisPointer: { type: 'shadow' },
      backgroundColor: 'rgba(17,24,39,0.95)',
      borderColor: '#374151',
      textStyle: { color: '#f1f5f9', fontSize: 12 },
    },
    grid: { top: 20, right: 30, bottom: 60, left: 80 },
    xAxis: {
      type: 'category',
      data: retailData.byIndustry.map(d => d.name),
      axisLine: { lineStyle: { color: '#334155' } },
      axisLabel: { color: '#94a3b8', fontSize: 10, rotate: 30 },
    },
    yAxis: {
      type: 'value',
      axisLine: { lineStyle: { color: '#334155' } },
      splitLine: { lineStyle: { color: '#1e293b', type: 'dashed' } },
      axisLabel: { color: '#64748b', fontSize: 11, formatter: '{value}%' },
    },
    series: [{
      type: 'bar',
      data: retailData.byIndustry.map(d => ({
        value: d.yoy,
        itemStyle: { color: d.yoy > 10 ? '#ef4444' : d.yoy > 5 ? '#f59e0b' : '#3b82f6', borderRadius: 2 },
      })),
      barWidth: '50%',
    }],
  };

  return (
    <div className="space-y-4">
      <AnalysisCard title="最新社零数据解读" content={retailData.analysis} updateTime="2026-04-15" />
      <div className="grid grid-cols-2 gap-4">
        <ChartCard title="社会消费品零售总额当月同比" subtitle="2024.01-2026.03">
          <ReactECharts option={yoyOption} style={{ height: 280 }} />
        </ChartCard>
        <ChartCard title="细分行业社零当月同比变化" subtitle="2026年4月">
          <ReactECharts option={industryOption} style={{ height: 280 }} />
        </ChartCard>
      </div>
    </div>
  );
}
