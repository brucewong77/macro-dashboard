import { AnalysisCard } from '../components/AnalysisCard';
import { ChartCard } from '../components/ChartCard';
import { realestateData, months } from '../data/economicData';
import ReactECharts from 'echarts-for-react';

const commonOption = {
  backgroundColor: 'transparent',
  tooltip: {
    trigger: 'axis',
    backgroundColor: 'rgba(17,24,39,0.95)',
    borderColor: '#374151',
    textStyle: { color: '#f1f5f9', fontSize: 12 },
  },
  grid: { top: 30, right: 20, bottom: 30, left: 60 },
  xAxis: {
    type: 'category',
    data: months,
    axisLine: { lineStyle: { color: '#334155' } },
    axisLabel: { color: '#64748b', fontSize: 11 },
  },
};

export function RealEstateModule() {
  const salesAreaAccumOption = {
    ...commonOption,
    yAxis: { type: 'value', axisLine: { lineStyle: { color: '#334155' } }, splitLine: { lineStyle: { color: '#1e293b', type: 'dashed' } }, axisLabel: { color: '#64748b', fontSize: 11 } },
    series: [{
      type: 'bar',
      data: realestateData.salesAreaAccum.map(d => d.value),
      itemStyle: { color: '#3b82f6', borderRadius: 2 },
      barWidth: '50%',
    }],
  };

  const salesAreaAccumYoyOption = {
    ...commonOption,
    yAxis: { type: 'value', axisLine: { lineStyle: { color: '#334155' } }, splitLine: { lineStyle: { color: '#1e293b', type: 'dashed' } }, axisLabel: { color: '#64748b', fontSize: 11, formatter: '{value}%' } },
    series: [{
      type: 'line',
      data: realestateData.salesAreaAccumYoy.map(d => d.value),
      lineStyle: { color: '#ef4444', width: 2 },
      itemStyle: { color: '#ef4444' },
      symbol: 'circle',
      symbolSize: 4,
    }],
  };

  const salesAreaMonthOption = {
    ...commonOption,
    legend: { data: ['当月值', '当月同比', '当月环比'], top: 0, right: 0, textStyle: { color: '#94a3b8', fontSize: 10 } },
    yAxis: [
      { type: 'value', axisLine: { lineStyle: { color: '#334155' } }, splitLine: { lineStyle: { color: '#1e293b', type: 'dashed' } }, axisLabel: { color: '#64748b', fontSize: 11 } },
      { type: 'value', axisLine: { lineStyle: { color: '#334155' } }, splitLine: { show: false }, axisLabel: { color: '#64748b', fontSize: 11, formatter: '{value}%' } },
    ],
    series: [
      { name: '当月值', type: 'bar', data: realestateData.salesAreaMonth.map(d => d.value), itemStyle: { color: '#3b82f6', borderRadius: 2 }, barWidth: '40%', yAxisIndex: 0 },
      { name: '当月同比', type: 'line', data: realestateData.salesAreaMonthYoy.map(d => d.value), lineStyle: { color: '#ef4444', width: 2 }, itemStyle: { color: '#ef4444' }, symbol: 'circle', symbolSize: 3, yAxisIndex: 1 },
      { name: '当月环比', type: 'line', data: realestateData.salesAreaMom.map(d => d.value), lineStyle: { color: '#22c55e', width: 2 }, itemStyle: { color: '#22c55e' }, symbol: 'circle', symbolSize: 3, yAxisIndex: 1 },
    ],
  };

  const salesValueAccumOption = {
    ...commonOption,
    yAxis: { type: 'value', axisLine: { lineStyle: { color: '#334155' } }, splitLine: { lineStyle: { color: '#1e293b', type: 'dashed' } }, axisLabel: { color: '#64748b', fontSize: 11 } },
    series: [{
      type: 'bar',
      data: realestateData.salesValueAccum.map(d => d.value),
      itemStyle: { color: '#f59e0b', borderRadius: 2 },
      barWidth: '50%',
    }],
  };

  const salesValueAccumYoyOption = {
    ...commonOption,
    yAxis: { type: 'value', axisLine: { lineStyle: { color: '#334155' } }, splitLine: { lineStyle: { color: '#1e293b', type: 'dashed' } }, axisLabel: { color: '#64748b', fontSize: 11, formatter: '{value}%' } },
    series: [{
      type: 'line',
      data: realestateData.salesValueAccumYoy.map(d => d.value),
      lineStyle: { color: '#ef4444', width: 2 },
      itemStyle: { color: '#ef4444' },
      symbol: 'circle',
      symbolSize: 4,
    }],
  };

  const salesValueMonthOption = {
    ...commonOption,
    yAxis: { type: 'value', axisLine: { lineStyle: { color: '#334155' } }, splitLine: { lineStyle: { color: '#1e293b', type: 'dashed' } }, axisLabel: { color: '#64748b', fontSize: 11 } },
    series: [{
      type: 'bar',
      data: realestateData.salesValueMonth.map(d => d.value),
      itemStyle: { color: '#f59e0b', borderRadius: 2 },
      barWidth: '50%',
    }],
  };

  const avgPriceOption = {
    ...commonOption,
    yAxis: { type: 'value', axisLine: { lineStyle: { color: '#334155' } }, splitLine: { lineStyle: { color: '#1e293b', type: 'dashed' } }, axisLabel: { color: '#64748b', fontSize: 11 } },
    series: [{
      type: 'line',
      data: realestateData.avgPrice.map(d => d.value),
      lineStyle: { color: '#8b5cf6', width: 2 },
      itemStyle: { color: '#8b5cf6' },
      symbol: 'circle',
      symbolSize: 4,
      areaStyle: {
        color: { type: 'linear', x: 0, y: 0, x2: 0, y2: 1, colorStops: [
          { offset: 0, color: 'rgba(139,92,246,0.15)' },
          { offset: 1, color: 'rgba(139,92,246,0)' },
        ]},
      },
    }],
  };

  const secondhandOption = {
    backgroundColor: 'transparent',
    tooltip: {
      trigger: 'axis',
      backgroundColor: 'rgba(17,24,39,0.95)',
      borderColor: '#374151',
      textStyle: { color: '#f1f5f9', fontSize: 12 },
    },
    legend: { data: ['二手销售面积', '二手销售额'], top: 0, right: 0, textStyle: { color: '#94a3b8', fontSize: 11 } },
    grid: { top: 30, right: 50, bottom: 30, left: 60 },
    xAxis: {
      type: 'category',
      data: months,
      axisLine: { lineStyle: { color: '#334155' } },
      axisLabel: { color: '#64748b', fontSize: 11 },
    },
    yAxis: [
      { type: 'value', name: '面积(万㎡)', axisLine: { lineStyle: { color: '#334155' } }, splitLine: { lineStyle: { color: '#1e293b', type: 'dashed' } }, axisLabel: { color: '#64748b', fontSize: 11 } },
      { type: 'value', name: '金额(亿元)', axisLine: { lineStyle: { color: '#334155' } }, splitLine: { show: false }, axisLabel: { color: '#64748b', fontSize: 11 } },
    ],
    series: [
      { name: '二手销售面积', type: 'bar', data: realestateData.secondhand.area, itemStyle: { color: '#3b82f6', borderRadius: 2 }, barWidth: '40%', yAxisIndex: 0 },
      { name: '二手销售额', type: 'line', data: realestateData.secondhand.value, lineStyle: { color: '#ef4444', width: 2 }, itemStyle: { color: '#ef4444' }, symbol: 'circle', symbolSize: 4, yAxisIndex: 1 },
    ],
  };

  return (
    <div className="space-y-4">
      <AnalysisCard title="最新房地产数据解读" content={realestateData.analysis} updateTime="2026-04-15" />
      <div className="grid grid-cols-3 gap-4">
        <ChartCard title="商品房销售面积年度累计值" subtitle="亿平方米">
          <ReactECharts option={salesAreaAccumOption} style={{ height: 220 }} />
        </ChartCard>
        <ChartCard title="商品房销售面积累计同比" subtitle="%">
          <ReactECharts option={salesAreaAccumYoyOption} style={{ height: 220 }} />
        </ChartCard>
        <ChartCard title="商品房销售面积当月值/同比/环比" subtitle="亿平方米/%">
          <ReactECharts option={salesAreaMonthOption} style={{ height: 220 }} />
        </ChartCard>
      </div>
      <div className="grid grid-cols-3 gap-4">
        <ChartCard title="商品房销售额年度累计值" subtitle="万亿元">
          <ReactECharts option={salesValueAccumOption} style={{ height: 220 }} />
        </ChartCard>
        <ChartCard title="商品房销售额累计同比" subtitle="%">
          <ReactECharts option={salesValueAccumYoyOption} style={{ height: 220 }} />
        </ChartCard>
        <ChartCard title="商品房销售额当月值" subtitle="万亿元">
          <ReactECharts option={salesValueMonthOption} style={{ height: 220 }} />
        </ChartCard>
      </div>
      <div className="grid grid-cols-2 gap-4">
        <ChartCard title="商品房月度平均销售单价" subtitle="元/平方米">
          <ReactECharts option={avgPriceOption} style={{ height: 240 }} />
        </ChartCard>
        <ChartCard title="二手房销售面积和销售额" subtitle="万平方米/亿元">
          <ReactECharts option={secondhandOption} style={{ height: 240 }} />
        </ChartCard>
      </div>
    </div>
  );
}
