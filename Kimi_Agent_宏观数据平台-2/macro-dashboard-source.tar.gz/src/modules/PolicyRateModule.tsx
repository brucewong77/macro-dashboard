import { AnalysisCard } from '../components/AnalysisCard';
import { ChartCard } from '../components/ChartCard';
import { rateData, months } from '../data/economicData';
import ReactECharts from 'echarts-for-react';

const commonOption = {
  backgroundColor: 'transparent',
  tooltip: {
    trigger: 'axis',
    backgroundColor: 'rgba(17,24,39,0.95)',
    borderColor: '#374151',
    textStyle: { color: '#f1f5f9', fontSize: 12 },
  },
  grid: { top: 30, right: 50, bottom: 30, left: 50 },
  xAxis: {
    type: 'category',
    data: months,
    axisLine: { lineStyle: { color: '#334155' } },
    axisLabel: { color: '#64748b', fontSize: 11 },
  },
};

export function PolicyRateModule() {
  const mlfOption = {
    ...commonOption,
    legend: { data: ['MLF利率(%)', '投放量(亿元)'], top: 0, right: 0, textStyle: { color: '#94a3b8', fontSize: 10 } },
    yAxis: [
      { type: 'value', name: '利率%', axisLine: { lineStyle: { color: '#334155' } }, splitLine: { lineStyle: { color: '#1e293b', type: 'dashed' } }, axisLabel: { color: '#64748b', fontSize: 11 } },
      { type: 'value', name: '亿元', axisLine: { lineStyle: { color: '#334155' } }, splitLine: { show: false }, axisLabel: { color: '#64748b', fontSize: 11 } },
    ],
    series: [
      { name: 'MLF利率(%)', type: 'line', data: rateData.mlfRate, lineStyle: { color: '#3b82f6', width: 2 }, itemStyle: { color: '#3b82f6' }, symbol: 'circle', symbolSize: 4, yAxisIndex: 0 },
      { name: '投放量(亿元)', type: 'bar', data: rateData.mlfAmount, itemStyle: { color: '#3b82f6', borderRadius: 2, opacity: 0.5 }, barWidth: '40%', yAxisIndex: 1 },
    ],
  };

  const lprOption = {
    ...commonOption,
    legend: { data: ['1年期LPR', '5年期LPR'], top: 0, right: 0, textStyle: { color: '#94a3b8', fontSize: 11 } },
    yAxis: { type: 'value', axisLine: { lineStyle: { color: '#334155' } }, splitLine: { lineStyle: { color: '#1e293b', type: 'dashed' } }, axisLabel: { color: '#64748b', fontSize: 11, formatter: '{value}%' } },
    series: [
      { name: '1年期LPR', type: 'line', data: rateData.lpr1y, lineStyle: { color: '#3b82f6', width: 2 }, itemStyle: { color: '#3b82f6' }, symbol: 'circle', symbolSize: 4 },
      { name: '5年期LPR', type: 'line', data: rateData.lpr5y, lineStyle: { color: '#ef4444', width: 2 }, itemStyle: { color: '#ef4444' }, symbol: 'circle', symbolSize: 4 },
    ],
  };

  const repoRateOption = {
    ...commonOption,
    legend: { data: ['7天', '14天', '28天'], top: 0, right: 0, textStyle: { color: '#94a3b8', fontSize: 11 } },
    yAxis: { type: 'value', axisLine: { lineStyle: { color: '#334155' } }, splitLine: { lineStyle: { color: '#1e293b', type: 'dashed' } }, axisLabel: { color: '#64748b', fontSize: 11, formatter: '{value}%' } },
    series: [
      { name: '7天', type: 'line', data: rateData.repo7d, lineStyle: { color: '#3b82f6', width: 2 }, itemStyle: { color: '#3b82f6' }, symbol: 'circle', symbolSize: 3 },
      { name: '14天', type: 'line', data: rateData.repo14d, lineStyle: { color: '#ef4444', width: 2 }, itemStyle: { color: '#ef4444' }, symbol: 'circle', symbolSize: 3 },
      { name: '28天', type: 'line', data: rateData.repo28d, lineStyle: { color: '#22c55e', width: 2 }, itemStyle: { color: '#22c55e' }, symbol: 'circle', symbolSize: 3 },
    ],
  };

  const cdOption = {
    ...commonOption,
    legend: { data: ['3个月', '1年'], top: 0, right: 0, textStyle: { color: '#94a3b8', fontSize: 11 } },
    yAxis: { type: 'value', axisLine: { lineStyle: { color: '#334155' } }, splitLine: { lineStyle: { color: '#1e293b', type: 'dashed' } }, axisLabel: { color: '#64748b', fontSize: 11, formatter: '{value}%' } },
    series: [
      { name: '3个月', type: 'line', data: rateData.cd3m, lineStyle: { color: '#3b82f6', width: 2 }, itemStyle: { color: '#3b82f6' }, symbol: 'circle', symbolSize: 3 },
      { name: '1年', type: 'line', data: rateData.cd1y, lineStyle: { color: '#f59e0b', width: 2 }, itemStyle: { color: '#f59e0b' }, symbol: 'circle', symbolSize: 3 },
    ],
  };

  const interbankOption = {
    ...commonOption,
    legend: { data: ['1天', '7天'], top: 0, right: 0, textStyle: { color: '#94a3b8', fontSize: 11 } },
    yAxis: { type: 'value', axisLine: { lineStyle: { color: '#334155' } }, splitLine: { lineStyle: { color: '#1e293b', type: 'dashed' } }, axisLabel: { color: '#64748b', fontSize: 11, formatter: '{value}%' } },
    series: [
      { name: '1天', type: 'line', data: rateData.interbank1d, lineStyle: { color: '#3b82f6', width: 2 }, itemStyle: { color: '#3b82f6' }, symbol: 'circle', symbolSize: 3 },
      { name: '7天', type: 'line', data: rateData.interbank7d, lineStyle: { color: '#ef4444', width: 2 }, itemStyle: { color: '#ef4444' }, symbol: 'circle', symbolSize: 3 },
    ],
  };

  const repo7dmaOption = {
    ...commonOption,
    yAxis: { type: 'value', axisLine: { lineStyle: { color: '#334155' } }, splitLine: { lineStyle: { color: '#1e293b', type: 'dashed' } }, axisLabel: { color: '#64748b', fontSize: 11, formatter: '{value}%' } },
    series: [{
      type: 'line',
      data: rateData.repo7dma20,
      lineStyle: { color: '#8b5cf6', width: 2 },
      itemStyle: { color: '#8b5cf6' },
      symbol: 'none',
      smooth: true,
      areaStyle: {
        color: { type: 'linear', x: 0, y: 0, x2: 0, y2: 1, colorStops: [
          { offset: 0, color: 'rgba(139,92,246,0.15)' },
          { offset: 1, color: 'rgba(139,92,246,0)' },
        ]},
      },
    }],
  };

  return (
    <div className="space-y-4">
      <AnalysisCard title="最新政策利率数据解读" content={rateData.analysis} updateTime="2026-04-20" />
      <div className="grid grid-cols-2 gap-4">
        <ChartCard title="1年期MLF利率及投放量" subtitle="利率%/亿元">
          <ReactECharts option={mlfOption} style={{ height: 240 }} />
        </ChartCard>
        <ChartCard title="LPR变动" subtitle="1年期和5年期">
          <ReactECharts option={lprOption} style={{ height: 240 }} />
        </ChartCard>
      </div>
      <div className="grid grid-cols-3 gap-4">
        <ChartCard title="逆回购利率" subtitle="7天/14天/28天">
          <ReactECharts option={repoRateOption} style={{ height: 220 }} />
        </ChartCard>
        <ChartCard title="同业存单发行利率" subtitle="3个月和1年">
          <ReactECharts option={cdOption} style={{ height: 220 }} />
        </ChartCard>
        <ChartCard title="银行同业拆借利率" subtitle="1天和7天加权">
          <ReactECharts option={interbankOption} style={{ height: 220 }} />
        </ChartCard>
      </div>
      <ChartCard title="银行质押式回购加权利率(7天) 20日移动平均" subtitle="%" className="w-full">
        <ReactECharts option={repo7dmaOption} style={{ height: 220 }} />
      </ChartCard>
    </div>
  );
}
