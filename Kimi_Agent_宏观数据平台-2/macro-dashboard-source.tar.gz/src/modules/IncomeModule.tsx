import { AnalysisCard } from '../components/AnalysisCard';
import { ChartCard } from '../components/ChartCard';
import { incomeData, months } from '../data/economicData';
import ReactECharts from 'echarts-for-react';

export function IncomeModule() {
  const option = {
    backgroundColor: 'transparent',
    tooltip: {
      trigger: 'axis',
      backgroundColor: 'rgba(17,24,39,0.95)',
      borderColor: '#374151',
      textStyle: { color: '#f1f5f9', fontSize: 12 },
    },
    legend: { data: ['全国居民', '城镇居民', '农村居民'], top: 0, right: 0, textStyle: { color: '#94a3b8', fontSize: 11 } },
    grid: { top: 30, right: 20, bottom: 30, left: 60 },
    xAxis: {
      type: 'category',
      data: months,
      axisLine: { lineStyle: { color: '#334155' } },
      axisLabel: { color: '#64748b', fontSize: 11 },
    },
    yAxis: {
      type: 'value',
      axisLine: { lineStyle: { color: '#334155' } },
      splitLine: { lineStyle: { color: '#1e293b', type: 'dashed' } },
      axisLabel: { color: '#64748b', fontSize: 11, formatter: (v: number) => `${(v/10000).toFixed(1)}万` },
    },
    series: [
      { name: '全国居民', type: 'line', data: incomeData.national.map(d => d.value).filter(v => v !== 0), lineStyle: { color: '#3b82f6', width: 2 }, itemStyle: { color: '#3b82f6' }, symbol: 'circle', symbolSize: 4 },
      { name: '城镇居民', type: 'line', data: incomeData.urban.map(d => d.value).filter(v => v !== 0), lineStyle: { color: '#ef4444', width: 2 }, itemStyle: { color: '#ef4444' }, symbol: 'circle', symbolSize: 4 },
      { name: '农村居民', type: 'line', data: incomeData.rural.map(d => d.value).filter(v => v !== 0), lineStyle: { color: '#22c55e', width: 2 }, itemStyle: { color: '#22c55e' }, symbol: 'circle', symbolSize: 4 },
    ],
  };

  return (
    <div className="space-y-4">
      <AnalysisCard title="最新居民可支配收入数据解读" content={incomeData.analysis} updateTime="2026-04-15" />
      <ChartCard title="全国居民人均可支配收入" subtitle="元" className="w-full">
        <ReactECharts option={option} style={{ height: 360 }} />
      </ChartCard>
    </div>
  );
}
