import { AnalysisCard } from '../components/AnalysisCard';
import { ChartCard } from '../components/ChartCard';
import { fxReserveData, months } from '../data/economicData';
import ReactECharts from 'echarts-for-react';

export function FXReserveModule() {
  const amountOption = {
    backgroundColor: 'transparent',
    tooltip: {
      trigger: 'axis',
      backgroundColor: 'rgba(17,24,39,0.95)',
      borderColor: '#374151',
      textStyle: { color: '#f1f5f9', fontSize: 12 },
    },
    grid: { top: 30, right: 20, bottom: 30, left: 60 },
    xAxis: {
      type: 'category',
      data: months,
      axisLine: { lineStyle: { color: '#334155' } },
      axisLabel: { color: '#64748b', fontSize: 11 },
    },
    yAxis: {
      type: 'value',
      min: 30000,
      axisLine: { lineStyle: { color: '#334155' } },
      splitLine: { lineStyle: { color: '#1e293b', type: 'dashed' } },
      axisLabel: { color: '#64748b', fontSize: 11, formatter: (v: number) => `${(v/10000).toFixed(1)}万亿` },
    },
    series: [{
      type: 'bar',
      data: fxReserveData.amount.map(d => d.value),
      itemStyle: {
        color: { type: 'linear', x: 0, y: 0, x2: 0, y2: 1, colorStops: [
          { offset: 0, color: '#3b82f6' },
          { offset: 1, color: '#1e3a5f' },
        ]},
        borderRadius: 2,
      },
      barWidth: '50%',
    }],
  };

  const yoyMomOption = {
    backgroundColor: 'transparent',
    tooltip: {
      trigger: 'axis',
      backgroundColor: 'rgba(17,24,39,0.95)',
      borderColor: '#374151',
      textStyle: { color: '#f1f5f9', fontSize: 12 },
    },
    legend: { data: ['同比', '环比'], top: 0, right: 0, textStyle: { color: '#94a3b8', fontSize: 11 } },
    grid: { top: 30, right: 20, bottom: 30, left: 50 },
    xAxis: {
      type: 'category',
      data: months,
      axisLine: { lineStyle: { color: '#334155' } },
      axisLabel: { color: '#64748b', fontSize: 11 },
    },
    yAxis: {
      type: 'value',
      axisLine: { lineStyle: { color: '#334155' } },
      splitLine: { lineStyle: { color: '#1e293b', type: 'dashed' } },
      axisLabel: { color: '#64748b', fontSize: 11, formatter: '{value}%' },
    },
    series: [
      { name: '同比', type: 'line', data: fxReserveData.yoy.map(d => d.value), lineStyle: { color: '#3b82f6', width: 2 }, itemStyle: { color: '#3b82f6' }, symbol: 'circle', symbolSize: 4 },
      { name: '环比', type: 'line', data: fxReserveData.mom.map(d => d.value), lineStyle: { color: '#22c55e', width: 2 }, itemStyle: { color: '#22c55e' }, symbol: 'circle', symbolSize: 4 },
    ],
  };

  return (
    <div className="space-y-4">
      <AnalysisCard title="最新外汇储备数据解读" content={fxReserveData.analysis} updateTime="2026-04-30" />
      <div className="grid grid-cols-2 gap-4">
        <ChartCard title="外汇储备金额" subtitle="亿美元">
          <ReactECharts option={amountOption} style={{ height: 280 }} />
        </ChartCard>
        <ChartCard title="外汇储备当月同比、环比" subtitle="2024.01-2026.03">
          <ReactECharts option={yoyMomOption} style={{ height: 280 }} />
        </ChartCard>
      </div>
    </div>
  );
}
