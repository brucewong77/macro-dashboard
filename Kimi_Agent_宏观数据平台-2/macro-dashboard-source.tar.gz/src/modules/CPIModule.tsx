import { useState, useEffect } from 'react';
import { AnalysisCard } from '../components/AnalysisCard';
import { ChartCard } from '../components/ChartCard';
import { getCpiData, months } from '../data/api';
import ReactECharts from 'echarts-for-react';

const commonOption = {
  backgroundColor: 'transparent',
  tooltip: {
    trigger: 'axis',
    backgroundColor: 'rgba(17,24,39,0.95)',
    borderColor: '#374151',
    textStyle: { color: '#f1f5f9', fontSize: 12 },
  },
  grid: { top: 30, right: 20, bottom: 30, left: 50 },
  xAxis: {
    type: 'category',
    data: months,
    axisLine: { lineStyle: { color: '#334155' } },
    axisLabel: { color: '#64748b', fontSize: 11 },
  },
  yAxis: {
    type: 'value',
    axisLine: { lineStyle: { color: '#334155' } },
    splitLine: { lineStyle: { color: '#1e293b', type: 'dashed' } },
    axisLabel: { color: '#64748b', fontSize: 11, formatter: '{value}%' },
  },
};

export function CPIModule() {
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let mounted = true;
    getCpiData().then(d => {
      if (mounted) {
        setData(d);
        setLoading(false);
      }
    });
    return () => { mounted = false; };
  }, []);

  if (loading || !data) {
    return (
      <div className="space-y-4">
        <div className="bg-[#111827] border border-[#1f2937] rounded-lg p-5 animate-pulse">
          <div className="h-4 bg-[#1f2937] rounded w-1/4 mb-3" />
          <div className="h-3 bg-[#1f2937] rounded w-full mb-2" />
          <div className="h-3 bg-[#1f2937] rounded w-3/4" />
        </div>
        <div className="grid grid-cols-2 gap-4">
          {[1,2,3,4].map(i => (
            <div key={i} className="bg-[#111827] border border-[#1f2937] rounded-lg p-4 animate-pulse h-[320px]" />
          ))}
        </div>
      </div>
    );
  }

  const yoyValues = data.yoy?.map((d: any) => d.value) || [];
  const momValues = data.mom?.map((d: any) => d.value) || [];
  const coreYoyValues = data.coreYoy?.map((d: any) => d.value) || [];
  const coreMomValues = data.coreMom?.map((d: any) => d.value) || [];

  const yoyOption = {
    ...commonOption,
    series: [{
      type: 'line',
      data: yoyValues,
      lineStyle: { color: '#ef4444', width: 2 },
      itemStyle: { color: '#ef4444' },
      symbol: 'circle',
      symbolSize: 4,
      areaStyle: {
        color: { type: 'linear', x: 0, y: 0, x2: 0, y2: 1, colorStops: [
          { offset: 0, color: 'rgba(239,68,68,0.15)' },
          { offset: 1, color: 'rgba(239,68,68,0)' },
        ]},
      },
    }],
  };

  const momOption = {
    ...commonOption,
    series: [{
      type: 'line',
      data: momValues,
      lineStyle: { color: '#3b82f6', width: 2 },
      itemStyle: { color: '#3b82f6' },
      symbol: 'circle',
      symbolSize: 4,
      areaStyle: {
        color: { type: 'linear', x: 0, y: 0, x2: 0, y2: 1, colorStops: [
          { offset: 0, color: 'rgba(59,130,246,0.15)' },
          { offset: 1, color: 'rgba(59,130,246,0)' },
        ]},
        
      },
    }],
  };

  const coreOption = {
    backgroundColor: 'transparent',
    tooltip: {
      trigger: 'axis',
      backgroundColor: 'rgba(17,24,39,0.95)',
      borderColor: '#374151',
      textStyle: { color: '#f1f5f9', fontSize: 12 },
    },
    legend: { data: ['核心CPI同比', '核心CPI环比'], top: 0, right: 0, textStyle: { color: '#94a3b8', fontSize: 11 } },
    grid: { top: 30, right: 50, bottom: 30, left: 50 },
    xAxis: {
      type: 'category',
      data: months,
      axisLine: { lineStyle: { color: '#334155' } },
      axisLabel: { color: '#64748b', fontSize: 11 },
    },
    yAxis: [
      { type: 'value', axisLine: { lineStyle: { color: '#334155' } }, splitLine: { lineStyle: { color: '#1e293b', type: 'dashed' } }, axisLabel: { color: '#64748b', fontSize: 11, formatter: '{value}%' } },
      { type: 'value', axisLine: { lineStyle: { color: '#334155' } }, splitLine: { show: false }, axisLabel: { color: '#64748b', fontSize: 11, formatter: '{value}%' } },
    ],
    series: [
      { name: '核心CPI同比', type: 'line', yAxisIndex: 0, data: coreYoyValues, lineStyle: { color: '#8b5cf6', width: 2 }, itemStyle: { color: '#8b5cf6' }, symbol: 'circle', symbolSize: 4 },
      { name: '核心CPI环比', type: 'bar', yAxisIndex: 1, data: coreMomValues, itemStyle: { color: '#3b82f6', borderRadius: 2 }, barWidth: '40%' },
    ],
  };

  const subItemOption = {
    backgroundColor: 'transparent',
    tooltip: {
      trigger: 'axis',
      axisPointer: { type: 'shadow' },
      backgroundColor: 'rgba(17,24,39,0.95)',
      borderColor: '#374151',
      textStyle: { color: '#f1f5f9', fontSize: 12 },
    },
    legend: { data: ['同比', '环比'], top: 0, right: 0, textStyle: { color: '#94a3b8', fontSize: 11 } },
    grid: { top: 30, right: 20, bottom: 30, left: 80 },
    xAxis: {
      type: 'category',
      data: data.subItems?.map((d: any) => d.name) || [],
      axisLine: { lineStyle: { color: '#334155' } },
      axisLabel: { color: '#94a3b8', fontSize: 11 },
    },
    yAxis: {
      type: 'value',
      axisLine: { lineStyle: { color: '#334155' } },
      splitLine: { lineStyle: { color: '#1e293b', type: 'dashed' } },
      axisLabel: { color: '#64748b', fontSize: 11, formatter: '{value}%' },
    },
    series: [
      { name: '同比', type: 'bar', data: data.subItems?.map((d: any) => ({ value: d.yoy, itemStyle: { color: d.yoy >= 0 ? '#ef4444' : '#22c55e' } })) || [], barWidth: '30%', itemStyle: { borderRadius: 2 } },
      { name: '环比', type: 'bar', data: data.subItems?.map((d: any) => ({ value: d.mom, itemStyle: { color: d.mom >= 0 ? '#f59e0b' : '#3b82f6' } })) || [], barWidth: '30%', itemStyle: { borderRadius: 2 } },
    ],
  };

  return (
    <div className="space-y-4">
      <AnalysisCard title="最新 CPI 数据解读" content={data.analysis || ''} updateTime="2026-05-11" />
      <div className="grid grid-cols-2 gap-4">
        <ChartCard title="CPI 同比" subtitle="2024.01-2026.03">
          <ReactECharts option={yoyOption} style={{ height: 280 }} />
        </ChartCard>
        <ChartCard title="CPI 环比" subtitle="2024.01-2026.03">
          <ReactECharts option={momOption} style={{ height: 280 }} />
        </ChartCard>
      </div>
      <div className="grid grid-cols-2 gap-4">
        <ChartCard title="核心 CPI 同比与环比" subtitle="2024.01-2026.03">
          <ReactECharts option={coreOption} style={{ height: 280 }} />
        </ChartCard>
        <ChartCard title="CPI 细分项月度同比和环比" subtitle="2026年4月">
          <ReactECharts option={subItemOption} style={{ height: 280 }} />
        </ChartCard>
      </div>
    </div>
  );
}
