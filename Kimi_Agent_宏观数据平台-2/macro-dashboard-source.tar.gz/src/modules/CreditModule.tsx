import { AnalysisCard } from '../components/AnalysisCard';
import { ChartCard } from '../components/ChartCard';
import { creditData, months } from '../data/economicData';
import ReactECharts from 'echarts-for-react';

export function CreditModule() {
  const stackedOption = {
    backgroundColor: 'transparent',
    tooltip: {
      trigger: 'axis',
      axisPointer: { type: 'shadow' },
      backgroundColor: 'rgba(17,24,39,0.95)',
      borderColor: '#374151',
      textStyle: { color: '#f1f5f9', fontSize: 12 },
    },
    legend: { data: ['居民短期', '居民中长期', '企业短期', '企业中长期', '票据融资'], top: 0, right: 0, textStyle: { color: '#94a3b8', fontSize: 10 } },
    grid: { top: 30, right: 20, bottom: 30, left: 50 },
    xAxis: {
      type: 'category',
      data: months,
      axisLine: { lineStyle: { color: '#334155' } },
      axisLabel: { color: '#64748b', fontSize: 11 },
    },
    yAxis: {
      type: 'value',
      axisLine: { lineStyle: { color: '#334155' } },
      splitLine: { lineStyle: { color: '#1e293b', type: 'dashed' } },
      axisLabel: { color: '#64748b', fontSize: 11, formatter: '{value}万亿' },
    },
    series: [
      { name: '居民短期', type: 'bar', stack: 'total', data: creditData.householdShort.map(d => d.value), itemStyle: { color: '#3b82f6' } },
      { name: '居民中长期', type: 'bar', stack: 'total', data: creditData.householdLong.map(d => d.value), itemStyle: { color: '#22c55e' } },
      { name: '企业短期', type: 'bar', stack: 'total', data: creditData.enterpriseShort.map(d => d.value), itemStyle: { color: '#f59e0b' } },
      { name: '企业中长期', type: 'bar', stack: 'total', data: creditData.enterpriseLong.map(d => d.value), itemStyle: { color: '#ef4444' } },
      { name: '票据融资', type: 'bar', stack: 'total', data: creditData.billFinancing.map(d => d.value), itemStyle: { color: '#8b5cf6' } },
    ],
  };

  const focusOption = {
    backgroundColor: 'transparent',
    tooltip: {
      trigger: 'axis',
      axisPointer: { type: 'shadow' },
      backgroundColor: 'rgba(17,24,39,0.95)',
      borderColor: '#374151',
      textStyle: { color: '#f1f5f9', fontSize: 12 },
    },
    legend: { data: ['居民短期', '居民中长期', '企业短期', '企业中长期'], top: 0, right: 0, textStyle: { color: '#94a3b8', fontSize: 10 } },
    grid: { top: 30, right: 20, bottom: 30, left: 50 },
    xAxis: {
      type: 'category',
      data: months.slice(-12),
      axisLine: { lineStyle: { color: '#334155' } },
      axisLabel: { color: '#64748b', fontSize: 11 },
    },
    yAxis: {
      type: 'value',
      axisLine: { lineStyle: { color: '#334155' } },
      splitLine: { lineStyle: { color: '#1e293b', type: 'dashed' } },
      axisLabel: { color: '#64748b', fontSize: 11, formatter: '{value}万亿' },
    },
    series: [
      { name: '居民短期', type: 'bar', data: creditData.householdShort.slice(-12).map(d => d.value), itemStyle: { color: '#3b82f6' }, barWidth: '15%' },
      { name: '居民中长期', type: 'bar', data: creditData.householdLong.slice(-12).map(d => d.value), itemStyle: { color: '#22c55e' }, barWidth: '15%' },
      { name: '企业短期', type: 'bar', data: creditData.enterpriseShort.slice(-12).map(d => d.value), itemStyle: { color: '#f59e0b' }, barWidth: '15%' },
      { name: '企业中长期', type: 'bar', data: creditData.enterpriseLong.slice(-12).map(d => d.value), itemStyle: { color: '#ef4444' }, barWidth: '15%' },
    ],
  };

  return (
    <div className="space-y-4">
      <AnalysisCard title="最新信贷数据解读" content="2026年4月人民币贷款增加1.45万亿元。分部门看，住户贷款减少3500亿元，其中短期贷款减少2200亿元，中长期贷款减少1300亿元；企（事）业单位贷款增加1.82万亿元，其中短期贷款增加4500亿元，中长期贷款增加1.25万亿元，票据融资增加1200亿元。企业贷款需求保持旺盛，居民贷款延续偏弱态势。" updateTime="2026-04-15" />
      <div className="grid grid-cols-2 gap-4">
        <ChartCard title="人民币贷款细分项目" subtitle="2024.01-2026.03">
          <ReactECharts option={stackedOption} style={{ height: 300 }} />
        </ChartCard>
        <ChartCard title="居民和企业短期、中长期贷款变化" subtitle="近12个月">
          <ReactECharts option={focusOption} style={{ height: 300 }} />
        </ChartCard>
      </div>
    </div>
  );
}
