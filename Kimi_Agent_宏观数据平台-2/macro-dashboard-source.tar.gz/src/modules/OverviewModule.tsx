import { useState, useEffect } from 'react';
import { AnalysisCard } from '../components/AnalysisCard';
import { ChartCard } from '../components/ChartCard';
import { getCpiData, getPpiData, months } from '../data/api';
import ReactECharts from 'echarts-for-react';

export function OverviewModule() {
  const [cpiData, setCpiData] = useState<any>(null);
  const [ppiData, setPpiData] = useState<any>(null);
  useEffect(() => {
    let mounted = true;
    Promise.all([getCpiData(), getPpiData()]).then(([cpi, ppi]) => {
      if (mounted) {
        setCpiData(cpi);
        setPpiData(ppi);
      }
    });
    return () => { mounted = false; };
  }, []);

  const latestCPI = cpiData?.yoy?.[cpiData.yoy.length - 1]?.value ?? '1.2';
  const latestPPI = ppiData?.yoy?.[ppiData.yoy.length - 1]?.value ?? '2.8';
  const latestPMI = '49.8';

  const trendOption = {
    backgroundColor: 'transparent',
    grid: { top: 40, right: 40, bottom: 30, left: 50 },
    tooltip: { trigger: 'axis', backgroundColor: 'rgba(17,24,39,0.95)', borderColor: '#374151', textStyle: { color: '#f1f5f9', fontSize: 12 } },
    legend: { data: ['CPI同比', 'PPI同比'], top: 0, right: 0, textStyle: { color: '#94a3b8', fontSize: 12 } },
    xAxis: { type: 'category', data: months, axisLine: { lineStyle: { color: '#334155' } }, axisLabel: { color: '#64748b', fontSize: 11 } },
    yAxis: { type: 'value', axisLine: { lineStyle: { color: '#334155' } }, splitLine: { lineStyle: { color: '#1e293b', type: 'dashed' } }, axisLabel: { color: '#64748b', fontSize: 11, formatter: '{value}%' } },
    series: [
      { name: 'CPI同比', type: 'line', data: cpiData?.yoy?.map((d: any) => d.value) || [], lineStyle: { color: '#3b82f6', width: 2 }, itemStyle: { color: '#3b82f6' }, symbol: 'circle', symbolSize: 4, areaStyle: { color: { type: 'linear', x: 0, y: 0, x2: 0, y2: 1, colorStops: [{ offset: 0, color: 'rgba(59,130,246,0.15)' }, { offset: 1, color: 'rgba(59,130,246,0)' }] } } },
      { name: 'PPI同比', type: 'line', data: ppiData?.yoy?.map((d: any) => d.value) || [], lineStyle: { color: '#ef4444', width: 2 }, itemStyle: { color: '#ef4444' }, symbol: 'circle', symbolSize: 4, areaStyle: { color: { type: 'linear', x: 0, y: 0, x2: 0, y2: 1, colorStops: [{ offset: 0, color: 'rgba(239,68,68,0.15)' }, { offset: 1, color: 'rgba(239,68,68,0)' }] } } },
    ],
  };

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-4 gap-4">
        {[
          { label: 'GDP增速(Q1)', value: '5.0%', change: '+0.2%', up: true },
          { label: 'CPI同比', value: `${latestCPI}%`, change: '+0.2%', up: true },
          { label: 'PPI同比', value: `${latestPPI}%`, change: '+2.3%', up: true },
          { label: '制造业PMI', value: latestPMI, change: '-0.4%', up: false },
        ].map((kpi, i) => (
          <div key={i} className="bg-[#111827] border border-[#1f2937] rounded-lg p-5 hover:border-[#374151] transition-colors">
            <div className="text-sm text-[#64748b] mb-2">{kpi.label}</div>
            <div className="text-2xl font-bold text-[#f1f5f9] tabular-nums mb-2">{kpi.value}</div>
            <div className={`text-sm flex items-center gap-1 ${kpi.up ? 'text-[#ef4444]' : 'text-[#22c55e]'}`}>
              <span>{kpi.up ? '↗' : '↘'}</span><span>环比{kpi.change}</span>
            </div>
          </div>
        ))}
      </div>

      <AnalysisCard title="宏观经济数据概览" content="2026年4月，宏观经济运行总体平稳。物价水平温和回升，CPI同比上涨1.2%，PPI同比由降转涨至2.8%。制造业PMI略低于荣枯线，工业生产保持较快增长，消费市场稳步恢复。外贸出口增速回升，外汇储备规模稳定。金融数据总体稳健，社融和信贷保持合理增长。" updateTime="2026-05-11" />

      <div className="grid grid-cols-3 gap-4">
        <ChartCard title="CPI & PPI 走势" subtitle="2024.01-2026.03" className="col-span-2">
          <ReactECharts option={trendOption} style={{ height: 320 }} />
        </ChartCard>
        <ChartCard title="近期重点关注" subtitle="数据发布日历">
          <div className="space-y-2">
            {[{ date: '05-11', event: 'CPI、PPI数据发布', status: '已发布' }, { date: '05-15', event: '固定资产投资数据', status: '待发布' }, { date: '05-17', event: '社会消费品零售总额', status: '待发布' }, { date: '05-20', event: 'LPR报价', status: '待发布' }, { date: '05-27', event: '工业企业利润', status: '待发布' }, { date: '05-31', event: '制造业PMI', status: '待发布' }].map((item, i) => (
              <div key={i} className="flex items-center justify-between py-2 border-b border-[#1f2937] last:border-0">
                <div><div className="text-xs text-[#64748b]">{item.date}</div><div className="text-sm text-[#f1f5f9]">{item.event}</div></div>
                <span className={`text-xs px-2 py-0.5 rounded ${item.status === '已发布' ? 'bg-[#22c55e]/20 text-[#22c55e]' : 'bg-[#f59e0b]/20 text-[#f59e0b]'}`}>{item.status}</span>
              </div>
            ))}
          </div>
        </ChartCard>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <ChartCard title="数据预警提示">
          <div className="space-y-2">
            <div className="flex items-center gap-2 text-sm text-[#f59e0b]"><span>⚠</span><span>PPI同比涨幅扩大至2.8%，关注通胀传导风险</span></div>
            <div className="flex items-center gap-2 text-sm text-[#f59e0b]"><span>⚠</span><span>制造业PMI低于荣枯线，关注工业生产动能</span></div>
            <div className="flex items-center gap-2 text-sm text-[#22c55e]"><span>✓</span><span>M2-M1剪刀差收窄，资金活化程度改善</span></div>
            <div className="flex items-center gap-2 text-sm text-[#22c55e]"><span>✓</span><span>外汇储备规模稳定，国际收支基本平衡</span></div>
          </div>
        </ChartCard>
        <ChartCard title="关键指标速览">
          <div className="grid grid-cols-2 gap-3">
            {[{ label: '社融存量增速', value: '8.5%' }, { label: 'M2同比增速', value: '8.5%' }, { label: '出口同比', value: '6.8%' }, { label: '社零同比', value: '5.6%' }, { label: '固投累计同比', value: '4.0%' }, { label: '失业率', value: '5.1%' }, { label: '外汇储备', value: '3.28万亿$' }, { label: 'LPR(1年)', value: '3.45%' }].map((item, i) => (
              <div key={i} className="bg-[#0a0e1a] rounded px-3 py-2"><div className="text-xs text-[#64748b]">{item.label}</div><div className="text-sm font-semibold text-[#f1f5f9] tabular-nums">{item.value}</div></div>
            ))}
          </div>
        </ChartCard>
      </div>
    </div>
  );
}
