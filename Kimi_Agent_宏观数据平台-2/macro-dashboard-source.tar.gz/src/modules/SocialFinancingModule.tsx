import { AnalysisCard } from '../components/AnalysisCard';
import { ChartCard } from '../components/ChartCard';
import { socialFinancingData, months } from '../data/economicData';
import ReactECharts from 'echarts-for-react';

const commonOption = {
  backgroundColor: 'transparent',
  tooltip: {
    trigger: 'axis',
    backgroundColor: 'rgba(17,24,39,0.95)',
    borderColor: '#374151',
    textStyle: { color: '#f1f5f9', fontSize: 12 },
  },
  grid: { top: 30, right: 20, bottom: 30, left: 50 },
  xAxis: {
    type: 'category',
    data: months,
    axisLine: { lineStyle: { color: '#334155' } },
    axisLabel: { color: '#64748b', fontSize: 11 },
  },
  yAxis: {
    type: 'value',
    axisLine: { lineStyle: { color: '#334155' } },
    splitLine: { lineStyle: { color: '#1e293b', type: 'dashed' } },
    axisLabel: { color: '#64748b', fontSize: 11, formatter: '{value}%' },
  },
};

export function SocialFinancingModule() {
  const yoyOption = {
    ...commonOption,
    series: [{
      type: 'line',
      data: socialFinancingData.yoy.map(d => d.value),
      lineStyle: { color: '#3b82f6', width: 2 },
      itemStyle: { color: '#3b82f6' },
      symbol: 'circle',
      symbolSize: 4,
      areaStyle: {
        color: { type: 'linear', x: 0, y: 0, x2: 0, y2: 1, colorStops: [
          { offset: 0, color: 'rgba(59,130,246,0.15)' },
          { offset: 1, color: 'rgba(59,130,246,0)' },
        ]},
      },
    }],
  };

  const valueOption = {
    ...commonOption,
    yAxis: { type: 'value', axisLine: { lineStyle: { color: '#334155' } }, splitLine: { lineStyle: { color: '#1e293b', type: 'dashed' } }, axisLabel: { color: '#64748b', fontSize: 11, formatter: '{value}万亿' } },
    series: [{
      type: 'bar',
      data: socialFinancingData.monthlyValue.map(d => ({
        value: d.value,
        itemStyle: { color: d.value >= 3 ? '#ef4444' : '#3b82f6', borderRadius: 2 },
      })),
      barWidth: '50%',
    }],
  };

  const breakdownOption = {
    backgroundColor: 'transparent',
    tooltip: {
      trigger: 'axis',
      axisPointer: { type: 'shadow' },
      backgroundColor: 'rgba(17,24,39,0.95)',
      borderColor: '#374151',
      textStyle: { color: '#f1f5f9', fontSize: 12 },
    },
    legend: { data: ['人民币贷款', '企业债券', '政府债券', '股票融资'], top: 0, right: 0, textStyle: { color: '#94a3b8', fontSize: 10 } },
    grid: { top: 30, right: 20, bottom: 30, left: 50 },
    xAxis: {
      type: 'category',
      data: months,
      axisLine: { lineStyle: { color: '#334155' } },
      axisLabel: { color: '#64748b', fontSize: 11 },
    },
    yAxis: {
      type: 'value',
      axisLine: { lineStyle: { color: '#334155' } },
      splitLine: { lineStyle: { color: '#1e293b', type: 'dashed' } },
      axisLabel: { color: '#64748b', fontSize: 11, formatter: '{value}万亿' },
    },
    series: [
      { name: '人民币贷款', type: 'bar', stack: 'total', data: socialFinancingData.breakdown.rmbLoan.map(d => d.value), itemStyle: { color: '#3b82f6' }, barWidth: '50%' },
      { name: '企业债券', type: 'bar', stack: 'total', data: socialFinancingData.breakdown.entBond.map(d => d.value), itemStyle: { color: '#22c55e' } },
      { name: '政府债券', type: 'bar', stack: 'total', data: socialFinancingData.breakdown.govBond.map(d => d.value), itemStyle: { color: '#f59e0b' } },
      { name: '股票融资', type: 'bar', stack: 'total', data: socialFinancingData.breakdown.stock.map(d => d.value), itemStyle: { color: '#ef4444' } },
    ],
  };

  const yoyBreakdownOption = {
    backgroundColor: 'transparent',
    tooltip: {
      trigger: 'axis',
      axisPointer: { type: 'shadow' },
      backgroundColor: 'rgba(17,24,39,0.95)',
      borderColor: '#374151',
      textStyle: { color: '#f1f5f9', fontSize: 12 },
    },
    legend: { data: ['人民币贷款同比', '企业债券同比', '政府债券同比'], top: 0, right: 0, textStyle: { color: '#94a3b8', fontSize: 10 } },
    grid: { top: 30, right: 20, bottom: 30, left: 50 },
    xAxis: {
      type: 'category',
      data: months,
      axisLine: { lineStyle: { color: '#334155' } },
      axisLabel: { color: '#64748b', fontSize: 11 },
    },
    yAxis: {
      type: 'value',
      axisLine: { lineStyle: { color: '#334155' } },
      splitLine: { lineStyle: { color: '#1e293b', type: 'dashed' } },
      axisLabel: { color: '#64748b', fontSize: 11, formatter: '{value}%' },
    },
    series: [
      { name: '人民币贷款同比', type: 'bar', data: socialFinancingData.breakdownYoy.rmbLoan, itemStyle: { color: '#3b82f6' }, barWidth: '20%' },
      { name: '企业债券同比', type: 'bar', data: socialFinancingData.breakdownYoy.entBond, itemStyle: { color: '#22c55e' }, barWidth: '20%' },
      { name: '政府债券同比', type: 'bar', data: socialFinancingData.breakdownYoy.govBond, itemStyle: { color: '#f59e0b' }, barWidth: '20%' },
    ],
  };

  return (
    <div className="space-y-4">
      <AnalysisCard title="最新社融数据解读" content={socialFinancingData.analysis} updateTime="2026-04-15" />
      <div className="grid grid-cols-2 gap-4">
        <ChartCard title="社融规模存量同比" subtitle="2024.01-2026.03">
          <ReactECharts option={yoyOption} style={{ height: 260 }} />
        </ChartCard>
        <ChartCard title="社融规模当月值" subtitle="万亿元">
          <ReactECharts option={valueOption} style={{ height: 260 }} />
        </ChartCard>
      </div>
      <div className="grid grid-cols-2 gap-4">
        <ChartCard title="社融细分项目每月金额" subtitle="万亿元">
          <ReactECharts option={breakdownOption} style={{ height: 280 }} />
        </ChartCard>
        <ChartCard title="社融细分项目每月同比" subtitle="%">
          <ReactECharts option={yoyBreakdownOption} style={{ height: 280 }} />
        </ChartCard>
      </div>
    </div>
  );
}
