import { useState, useEffect } from 'react';
import { AnalysisCard } from '../components/AnalysisCard';
import { ChartCard } from '../components/ChartCard';
import { getPpiData, months } from '../data/api';
import ReactECharts from 'echarts-for-react';

const commonOption = {
  backgroundColor: 'transparent',
  tooltip: {
    trigger: 'axis',
    backgroundColor: 'rgba(17,24,39,0.95)',
    borderColor: '#374151',
    textStyle: { color: '#f1f5f9', fontSize: 12 },
  },
  grid: { top: 30, right: 20, bottom: 30, left: 50 },
  xAxis: {
    type: 'category',
    data: months,
    axisLine: { lineStyle: { color: '#334155' } },
    axisLabel: { color: '#64748b', fontSize: 11 },
  },
  yAxis: {
    type: 'value',
    axisLine: { lineStyle: { color: '#334155' } },
    splitLine: { lineStyle: { color: '#1e293b', type: 'dashed' } },
    axisLabel: { color: '#64748b', fontSize: 11, formatter: '{value}%' },
  },
};

export function PPIModule() {
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let mounted = true;
    getPpiData().then(d => {
      if (mounted) { setData(d); setLoading(false); }
    });
    return () => { mounted = false; };
  }, []);

  if (loading || !data) return <div className="text-center text-[#64748b] py-10">加载中...</div>;

  const yoyValues = data.yoy?.map((d: any) => d.value) || [];
  const momValues = data.mom?.map((d: any) => d.value) || [];

  const yoyOption = {
    ...commonOption,
    series: [{
      type: 'line', data: yoyValues,
      lineStyle: { color: '#ef4444', width: 2 }, itemStyle: { color: '#ef4444' },
      symbol: 'circle', symbolSize: 4,
      areaStyle: { color: { type: 'linear', x: 0, y: 0, x2: 0, y2: 1, colorStops: [
        { offset: 0, color: 'rgba(239,68,68,0.15)' }, { offset: 1, color: 'rgba(239,68,68,0)' },
      ]}},
    }],
  };

  const momOption = {
    ...commonOption,
    series: [{
      type: 'line', data: momValues,
      lineStyle: { color: '#3b82f6', width: 2 }, itemStyle: { color: '#3b82f6' },
      symbol: 'circle', symbolSize: 4,
      areaStyle: { color: { type: 'linear', x: 0, y: 0, x2: 0, y2: 1, colorStops: [
        { offset: 0, color: 'rgba(59,130,246,0.15)' }, { offset: 1, color: 'rgba(59,130,246,0)' },
      ]}},
    }],
  };

  const heatmapOption = {
    backgroundColor: 'transparent',
    tooltip: { position: 'top', backgroundColor: 'rgba(17,24,39,0.95)', borderColor: '#374151', textStyle: { color: '#f1f5f9', fontSize: 12 } },
    grid: { top: 10, right: 10, bottom: 60, left: 100 },
    xAxis: { type: 'category', data: months, splitArea: { show: true, areaStyle: { color: 'transparent' } }, axisLine: { lineStyle: { color: '#334155' } }, axisLabel: { color: '#64748b', fontSize: 10, rotate: 45 } },
    yAxis: { type: 'category', data: data.heatmapItems || [], splitArea: { show: true, areaStyle: { color: 'transparent' } }, axisLine: { lineStyle: { color: '#334155' } }, axisLabel: { color: '#94a3b8', fontSize: 11 } },
    visualMap: { min: -2, max: 4, calculable: true, orient: 'horizontal', left: 'center', bottom: 0, textStyle: { color: '#94a3b8' }, inRange: { color: ['#22c55e', '#fbbf24', '#ef4444'] } },
    series: [{ type: 'heatmap', data: data.heatmapData || [], label: { show: true, color: '#f1f5f9', fontSize: 9, textShadowColor: 'rgba(0,0,0,0.5)', textShadowBlur: 2 }, itemStyle: { borderColor: '#1f2937', borderWidth: 1 } }],
  };

  const industryOption = {
    backgroundColor: 'transparent',
    tooltip: { trigger: 'axis', axisPointer: { type: 'shadow' }, backgroundColor: 'rgba(17,24,39,0.95)', borderColor: '#374151', textStyle: { color: '#f1f5f9', fontSize: 12 } },
    grid: { top: 10, right: 30, bottom: 20, left: 140 },
    xAxis: { type: 'value', axisLine: { lineStyle: { color: '#334155' } }, splitLine: { lineStyle: { color: '#1e293b', type: 'dashed' } }, axisLabel: { color: '#64748b', fontSize: 11, formatter: '{value}%' } },
    yAxis: { type: 'category', data: [...(data.industryMom || [])].sort((a: any, b: any) => a.value - b.value).map((d: any) => d.name), axisLine: { lineStyle: { color: '#334155' } }, axisLabel: { color: '#94a3b8', fontSize: 10 } },
    series: [{ type: 'bar', data: [...(data.industryMom || [])].sort((a: any, b: any) => a.value - b.value).map((d: any) => ({ value: d.value, itemStyle: { color: d.value >= 0 ? '#ef4444' : '#22c55e' } })), barWidth: '60%', itemStyle: { borderRadius: 2 } }],
  };

  return (
    <div className="space-y-4">
      <AnalysisCard title="最新 PPI 数据解读" content={data.analysis || ''} updateTime="2026-05-11" />
      <div className="grid grid-cols-2 gap-4">
        <ChartCard title="PPI 同比" subtitle="2024.01-2026.03">
          <ReactECharts option={yoyOption} style={{ height: 280 }} />
        </ChartCard>
        <ChartCard title="PPI 环比" subtitle="2024.01-2026.03">
          <ReactECharts option={momOption} style={{ height: 280 }} />
        </ChartCard>
      </div>
      <div className="grid grid-cols-2 gap-4">
        <ChartCard title="PPI 生产资料和生活资料细分项环比变动热力图" subtitle="2024.01-2026.03">
          <ReactECharts option={heatmapOption} style={{ height: 320 }} />
        </ChartCard>
        <ChartCard title="PPI 分行业出厂价格环比涨跌幅" subtitle="2026年4月">
          <ReactECharts option={industryOption} style={{ height: 320 }} />
        </ChartCard>
      </div>
    </div>
  );
}
