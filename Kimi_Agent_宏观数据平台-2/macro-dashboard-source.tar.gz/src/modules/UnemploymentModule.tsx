import { AnalysisCard } from '../components/AnalysisCard';
import { ChartCard } from '../components/ChartCard';
import { unemploymentData, months } from '../data/economicData';
import ReactECharts from 'echarts-for-react';

export function UnemploymentModule() {
  const nationalOption = {
    backgroundColor: 'transparent',
    tooltip: {
      trigger: 'axis',
      backgroundColor: 'rgba(17,24,39,0.95)',
      borderColor: '#374151',
      textStyle: { color: '#f1f5f9', fontSize: 12 },
    },
    grid: { top: 30, right: 20, bottom: 30, left: 50 },
    xAxis: {
      type: 'category',
      data: months,
      axisLine: { lineStyle: { color: '#334155' } },
      axisLabel: { color: '#64748b', fontSize: 11 },
    },
    yAxis: {
      type: 'value',
      min: 4,
      max: 6,
      axisLine: { lineStyle: { color: '#334155' } },
      splitLine: { lineStyle: { color: '#1e293b', type: 'dashed' } },
      axisLabel: { color: '#64748b', fontSize: 11, formatter: '{value}%' },
    },
    series: [{
      type: 'line',
      data: unemploymentData.national.map(d => d.value),
      lineStyle: { color: '#3b82f6', width: 2 },
      itemStyle: { color: '#3b82f6' },
      symbol: 'circle',
      symbolSize: 4,
      areaStyle: {
        color: { type: 'linear', x: 0, y: 0, x2: 0, y2: 1, colorStops: [
          { offset: 0, color: 'rgba(59,130,246,0.15)' },
          { offset: 1, color: 'rgba(59,130,246,0)' },
        ]},
      },
    }],
  };

  const ageOption = {
    backgroundColor: 'transparent',
    tooltip: {
      trigger: 'axis',
      backgroundColor: 'rgba(17,24,39,0.95)',
      borderColor: '#374151',
      textStyle: { color: '#f1f5f9', fontSize: 12 },
    },
    legend: { data: ['16-24岁', '25-59岁'], top: 0, right: 0, textStyle: { color: '#94a3b8', fontSize: 11 } },
    grid: { top: 30, right: 20, bottom: 30, left: 50 },
    xAxis: {
      type: 'category',
      data: months,
      axisLine: { lineStyle: { color: '#334155' } },
      axisLabel: { color: '#64748b', fontSize: 11 },
    },
    yAxis: {
      type: 'value',
      axisLine: { lineStyle: { color: '#334155' } },
      splitLine: { lineStyle: { color: '#1e293b', type: 'dashed' } },
      axisLabel: { color: '#64748b', fontSize: 11, formatter: '{value}%' },
    },
    series: [
      { name: '16-24岁', type: 'line', data: unemploymentData.byAge.youth.map(d => d.value), lineStyle: { color: '#ef4444', width: 2 }, itemStyle: { color: '#ef4444' }, symbol: 'circle', symbolSize: 4 },
      { name: '25-59岁', type: 'line', data: unemploymentData.byAge.prime.map(d => d.value), lineStyle: { color: '#22c55e', width: 2 }, itemStyle: { color: '#22c55e' }, symbol: 'circle', symbolSize: 4 },
    ],
  };

  return (
    <div className="space-y-4">
      <AnalysisCard title="最新城镇失业率数据解读" content={unemploymentData.analysis} updateTime="2026-04-15" />
      <div className="grid grid-cols-2 gap-4">
        <ChartCard title="城镇失业率" subtitle="2024.01-2026.03">
          <ReactECharts option={nationalOption} style={{ height: 280 }} />
        </ChartCard>
        <ChartCard title="分年龄阶段失业率" subtitle="2024.01-2026.03">
          <ReactECharts option={ageOption} style={{ height: 280 }} />
        </ChartCard>
      </div>
    </div>
  );
}
