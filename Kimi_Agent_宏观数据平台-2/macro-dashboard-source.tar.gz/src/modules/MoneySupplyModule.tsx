import { AnalysisCard } from '../components/AnalysisCard';
import { ChartCard } from '../components/ChartCard';
import { moneyData, months } from '../data/economicData';
import ReactECharts from 'echarts-for-react';

const commonOption = {
  backgroundColor: 'transparent',
  tooltip: {
    trigger: 'axis',
    backgroundColor: 'rgba(17,24,39,0.95)',
    borderColor: '#374151',
    textStyle: { color: '#f1f5f9', fontSize: 12 },
  },
  grid: { top: 30, right: 20, bottom: 30, left: 50 },
  xAxis: {
    type: 'category',
    data: months,
    axisLine: { lineStyle: { color: '#334155' } },
    axisLabel: { color: '#64748b', fontSize: 11 },
  },
  yAxis: {
    type: 'value',
    axisLine: { lineStyle: { color: '#334155' } },
    splitLine: { lineStyle: { color: '#1e293b', type: 'dashed' } },
    axisLabel: { color: '#64748b', fontSize: 11, formatter: '{value}%' },
  },
};

export function MoneySupplyModule() {
  const supplyOption = {
    ...commonOption,
    legend: { data: ['M0', 'M1', 'M2'], top: 0, right: 0, textStyle: { color: '#94a3b8', fontSize: 11 } },
    series: [
      { name: 'M0', type: 'line', data: moneyData.m0.map(d => d.value), lineStyle: { color: '#f59e0b', width: 2 }, itemStyle: { color: '#f59e0b' }, symbol: 'circle', symbolSize: 3 },
      { name: 'M1', type: 'line', data: moneyData.m1.map(d => d.value), lineStyle: { color: '#22c55e', width: 2 }, itemStyle: { color: '#22c55e' }, symbol: 'circle', symbolSize: 3 },
      { name: 'M2', type: 'line', data: moneyData.m2.map(d => d.value), lineStyle: { color: '#3b82f6', width: 2 }, itemStyle: { color: '#3b82f6' }, symbol: 'circle', symbolSize: 3 },
    ],
  };

  const diffOption = {
    ...commonOption,
    series: [{
      type: 'bar',
      data: moneyData.m2m1Diff.map(d => ({
        value: d.value,
        itemStyle: { color: d.value >= 0 ? '#ef4444' : '#22c55e', borderRadius: 2 },
      })),
      barWidth: '50%',
    }],
  };

  return (
    <div className="space-y-4">
      <AnalysisCard title="最新货币供应量数据解读" content={moneyData.analysis} updateTime="2026-04-15" />
      <div className="grid grid-cols-2 gap-4">
        <ChartCard title="M0、M1、M2 同比增速" subtitle="2024.01-2026.03">
          <ReactECharts option={supplyOption} style={{ height: 300 }} />
        </ChartCard>
        <ChartCard title="M2-M1 差值（剪刀差）" subtitle="百分点">
          <ReactECharts option={diffOption} style={{ height: 300 }} />
        </ChartCard>
      </div>
    </div>
  );
}
