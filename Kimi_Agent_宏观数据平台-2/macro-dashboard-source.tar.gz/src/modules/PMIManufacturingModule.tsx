import { AnalysisCard } from '../components/AnalysisCard';
import { ChartCard } from '../components/ChartCard';
import { pmiData } from '../data/economicData';
import ReactECharts from 'echarts-for-react';

const monthLabels = Array.from({ length: 12 }, (_, i) => `${i + 1}月`);

export function PMIManufacturingModule() {
  const lineOption = {
    backgroundColor: 'transparent',
    tooltip: {
      trigger: 'axis',
      backgroundColor: 'rgba(17,24,39,0.95)',
      borderColor: '#374151',
      textStyle: { color: '#f1f5f9', fontSize: 12 },
    },
    legend: { data: ['2024年', '2025年', '2026年'], top: 0, right: 0, textStyle: { color: '#94a3b8', fontSize: 11 } },
    grid: { top: 30, right: 20, bottom: 30, left: 50 },
    xAxis: {
      type: 'category',
      data: monthLabels,
      axisLine: { lineStyle: { color: '#334155' } },
      axisLabel: { color: '#64748b', fontSize: 11 },
    },
    yAxis: {
      type: 'value',
      min: 47,
      max: 53,
      axisLine: { lineStyle: { color: '#334155' } },
      splitLine: { lineStyle: { color: '#1e293b', type: 'dashed' } },
      axisLabel: { color: '#64748b', fontSize: 11 },
    },
    series: [
      { name: '2024年', type: 'line', data: pmiData.manufacturing['2024'].slice(0, 12), lineStyle: { color: '#3b82f6', width: 2 }, itemStyle: { color: '#3b82f6' }, symbol: 'circle', symbolSize: 4 },
      { name: '2025年', type: 'line', data: pmiData.manufacturing['2025'].slice(12, 24), lineStyle: { color: '#22c55e', width: 2 }, itemStyle: { color: '#22c55e' }, symbol: 'circle', symbolSize: 4 },
      { name: '2026年', type: 'line', data: pmiData.manufacturing['2026'].slice(24, 36), lineStyle: { color: '#f59e0b', width: 2 }, itemStyle: { color: '#f59e0b' }, symbol: 'circle', symbolSize: 4 },
      {
        name: '荣枯线', type: 'line', data: Array(12).fill(50),
        lineStyle: { color: '#64748b', width: 1, type: 'dashed' },
        itemStyle: { color: '#64748b' }, symbol: 'none',
      },
    ],
  };

  const heatmapOption = {
    backgroundColor: 'transparent',
    tooltip: {
      position: 'top',
      backgroundColor: 'rgba(17,24,39,0.95)',
      borderColor: '#374151',
      textStyle: { color: '#f1f5f9', fontSize: 12 },
    },
    grid: { top: 10, right: 10, bottom: 60, left: 110 },
    xAxis: {
      type: 'category',
      data: pmiData.manufacturing['2025'].slice(12, 24).map((_, i) => `${i + 1}月`),
      splitArea: { show: true, areaStyle: { color: 'transparent' } },
      axisLine: { lineStyle: { color: '#334155' } },
      axisLabel: { color: '#64748b', fontSize: 10 },
    },
    yAxis: {
      type: 'category',
      data: pmiData.heatmapItems,
      splitArea: { show: true, areaStyle: { color: 'transparent' } },
      axisLine: { lineStyle: { color: '#334155' } },
      axisLabel: { color: '#94a3b8', fontSize: 11 },
    },
    visualMap: {
      min: 45, max: 55,
      calculable: true, orient: 'horizontal', left: 'center', bottom: 0,
      textStyle: { color: '#94a3b8' },
      inRange: { color: ['#22c55e', '#fbbf24', '#ef4444'] },
    },
    series: [{
      type: 'heatmap',
      data: pmiData.heatmapData,
      label: { show: true, color: '#f1f5f9', fontSize: 9, textShadowColor: 'rgba(0,0,0,0.5)', textShadowBlur: 2 },
      itemStyle: { borderColor: '#1f2937', borderWidth: 1 },
    }],
  };

  return (
    <div className="space-y-4">
      <AnalysisCard title="最新制造业 PMI 数据解读" content={pmiData.analysis} updateTime="2026-04-30" />
      <div className="grid grid-cols-2 gap-4">
        <ChartCard title="制造业 PMI 走势（多年对比）" subtitle="横轴为1-12月">
          <ReactECharts option={lineOption} style={{ height: 300 }} />
        </ChartCard>
        <ChartCard title="PMI 细分项变动热力图" subtitle="2025年">
          <ReactECharts option={heatmapOption} style={{ height: 300 }} />
        </ChartCard>
      </div>
    </div>
  );
}
