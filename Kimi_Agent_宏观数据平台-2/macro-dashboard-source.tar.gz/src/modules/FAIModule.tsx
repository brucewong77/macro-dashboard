import { AnalysisCard } from '../components/AnalysisCard';
import { ChartCard } from '../components/ChartCard';
import { faiData, months } from '../data/economicData';
import ReactECharts from 'echarts-for-react';

const commonOption = {
  backgroundColor: 'transparent',
  tooltip: {
    trigger: 'axis',
    backgroundColor: 'rgba(17,24,39,0.95)',
    borderColor: '#374151',
    textStyle: { color: '#f1f5f9', fontSize: 12 },
  },
  grid: { top: 30, right: 20, bottom: 30, left: 50 },
  xAxis: {
    type: 'category',
    data: months,
    axisLine: { lineStyle: { color: '#334155' } },
    axisLabel: { color: '#64748b', fontSize: 11 },
  },
  yAxis: {
    type: 'value',
    axisLine: { lineStyle: { color: '#334155' } },
    splitLine: { lineStyle: { color: '#1e293b', type: 'dashed' } },
    axisLabel: { color: '#64748b', fontSize: 11, formatter: '{value}%' },
  },
};

export function FAIModule() {
  const accumOption = {
    ...commonOption,
    series: [{
      type: 'line',
      data: faiData.accumYoy.map(d => d.value),
      lineStyle: { color: '#3b82f6', width: 2 },
      itemStyle: { color: '#3b82f6' },
      symbol: 'circle',
      symbolSize: 4,
      areaStyle: {
        color: { type: 'linear', x: 0, y: 0, x2: 0, y2: 1, colorStops: [
          { offset: 0, color: 'rgba(59,130,246,0.15)' },
          { offset: 1, color: 'rgba(59,130,246,0)' },
        ]},
      },
    }],
  };

  const momOption = {
    ...commonOption,
    series: [{
      type: 'bar',
      data: faiData.mom.map(d => ({
        value: d.value,
        itemStyle: { color: d.value >= 0 ? '#ef4444' : '#22c55e', borderRadius: 2 },
      })),
      barWidth: '50%',
    }],
  };

  const sectorOption = {
    backgroundColor: 'transparent',
    tooltip: {
      trigger: 'axis',
      backgroundColor: 'rgba(17,24,39,0.95)',
      borderColor: '#374151',
      textStyle: { color: '#f1f5f9', fontSize: 12 },
    },
    legend: { data: ['制造业', '基础设施建设', '房地产投资'], top: 0, right: 0, textStyle: { color: '#94a3b8', fontSize: 10 } },
    grid: { top: 30, right: 20, bottom: 30, left: 50 },
    xAxis: {
      type: 'category',
      data: months,
      axisLine: { lineStyle: { color: '#334155' } },
      axisLabel: { color: '#64748b', fontSize: 11 },
    },
    yAxis: {
      type: 'value',
      axisLine: { lineStyle: { color: '#334155' } },
      splitLine: { lineStyle: { color: '#1e293b', type: 'dashed' } },
      axisLabel: { color: '#64748b', fontSize: 11, formatter: '{value}%' },
    },
    series: [
      { name: '制造业', type: 'line', data: faiData.bySector.manufacturing, lineStyle: { color: '#3b82f6', width: 2 }, itemStyle: { color: '#3b82f6' }, symbol: 'circle', symbolSize: 3 },
      { name: '基础设施建设', type: 'line', data: faiData.bySector.infrastructure, lineStyle: { color: '#22c55e', width: 2 }, itemStyle: { color: '#22c55e' }, symbol: 'circle', symbolSize: 3 },
      { name: '房地产投资', type: 'line', data: faiData.bySector.realEstate, lineStyle: { color: '#ef4444', width: 2 }, itemStyle: { color: '#ef4444' }, symbol: 'circle', symbolSize: 3 },
    ],
  };

  return (
    <div className="space-y-4">
      <AnalysisCard title="最新固定资产投资数据解读" content={faiData.analysis} updateTime="2026-04-15" />
      <div className="grid grid-cols-2 gap-4">
        <ChartCard title="固定资产投资完成额累计同比" subtitle="2024.01-2026.03">
          <ReactECharts option={accumOption} style={{ height: 260 }} />
        </ChartCard>
        <ChartCard title="固定资产投资完成额环比" subtitle="2024.01-2026.03">
          <ReactECharts option={momOption} style={{ height: 260 }} />
        </ChartCard>
      </div>
      <ChartCard title="分领域固定资产投资累计同比" subtitle="制造业、基建、房地产" className="w-full">
        <ReactECharts option={sectorOption} style={{ height: 280 }} />
      </ChartCard>
    </div>
  );
}
