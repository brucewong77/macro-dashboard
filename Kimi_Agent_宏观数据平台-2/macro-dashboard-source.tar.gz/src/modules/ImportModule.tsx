import { AnalysisCard } from '../components/AnalysisCard';
import { ChartCard } from '../components/ChartCard';
import { importData, months } from '../data/economicData';
import ReactECharts from 'echarts-for-react';

export function ImportModule() {
  const yoyOption = {
    backgroundColor: 'transparent',
    tooltip: {
      trigger: 'axis',
      backgroundColor: 'rgba(17,24,39,0.95)',
      borderColor: '#374151',
      textStyle: { color: '#f1f5f9', fontSize: 12 },
    },
    grid: { top: 30, right: 20, bottom: 30, left: 50 },
    xAxis: {
      type: 'category',
      data: months,
      axisLine: { lineStyle: { color: '#334155' } },
      axisLabel: { color: '#64748b', fontSize: 11 },
    },
    yAxis: {
      type: 'value',
      axisLine: { lineStyle: { color: '#334155' } },
      splitLine: { lineStyle: { color: '#1e293b', type: 'dashed' } },
      axisLabel: { color: '#64748b', fontSize: 11, formatter: '{value}%' },
    },
    series: [{
      type: 'line',
      data: importData.yoy.map(d => d.value),
      lineStyle: { color: '#22c55e', width: 2 },
      itemStyle: { color: '#22c55e' },
      symbol: 'circle',
      symbolSize: 4,
      areaStyle: {
        color: { type: 'linear', x: 0, y: 0, x2: 0, y2: 1, colorStops: [
          { offset: 0, color: 'rgba(34,197,94,0.15)' },
          { offset: 1, color: 'rgba(34,197,94,0)' },
        ]},
      },
    }],
  };

  const countryOption = {
    backgroundColor: 'transparent',
    tooltip: {
      trigger: 'item',
      backgroundColor: 'rgba(17,24,39,0.95)',
      borderColor: '#374151',
      textStyle: { color: '#f1f5f9', fontSize: 12 },
      formatter: '{b}: {c}亿美元 ({d}%)',
    },
    series: [{
      type: 'pie',
      radius: ['45%', '70%'],
      center: ['50%', '50%'],
      data: importData.byCountry.map((d, i) => ({
        name: d.name,
        value: d.value,
        itemStyle: { color: ['#3b82f6', '#ef4444', '#22c55e', '#f59e0b', '#8b5cf6', '#ec4899', '#64748b'][i] },
      })),
      label: { color: '#94a3b8', fontSize: 11, formatter: '{b}\n{d}%' },
      emphasis: {
        itemStyle: { shadowBlur: 10, shadowColor: 'rgba(0,0,0,0.5)' },
      },
    }],
  };

  const productOption = {
    backgroundColor: 'transparent',
    tooltip: {
      trigger: 'axis',
      axisPointer: { type: 'shadow' },
      backgroundColor: 'rgba(17,24,39,0.95)',
      borderColor: '#374151',
      textStyle: { color: '#f1f5f9', fontSize: 12 },
    },
    grid: { top: 10, right: 30, bottom: 20, left: 120 },
    xAxis: {
      type: 'value',
      axisLine: { lineStyle: { color: '#334155' } },
      splitLine: { lineStyle: { color: '#1e293b', type: 'dashed' } },
      axisLabel: { color: '#64748b', fontSize: 11 },
    },
    yAxis: {
      type: 'category',
      data: [...importData.byProduct].sort((a, b) => a.value - b.value).map(d => d.name),
      axisLine: { lineStyle: { color: '#334155' } },
      axisLabel: { color: '#94a3b8', fontSize: 10 },
    },
    series: [{
      type: 'bar',
      data: [...importData.byProduct].sort((a, b) => a.value - b.value).map(d => ({
        value: d.value,
        itemStyle: { color: '#22c55e', borderRadius: 2 },
      })),
      barWidth: '50%',
    }],
  };

  return (
    <div className="space-y-4">
      <AnalysisCard title="最新进口数据解读" content={importData.analysis} updateTime="2026-04-30" />
      <div className="grid grid-cols-2 gap-4">
        <ChartCard title="进口金额当月同比" subtitle="2024.01-2026.03">
          <ReactECharts option={yoyOption} style={{ height: 280 }} />
        </ChartCard>
        <ChartCard title="进口主要国家和地区" subtitle="2026年4月">
          <ReactECharts option={countryOption} style={{ height: 280 }} />
        </ChartCard>
      </div>
      <ChartCard title="进口主要产品" subtitle="亿美元" className="w-full">
        <ReactECharts option={productOption} style={{ height: 280 }} />
      </ChartCard>
    </div>
  );
}
