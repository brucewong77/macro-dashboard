import { useState, useCallback, createContext, useContext } from 'react';
import { Sidebar } from './components/Sidebar';
import { TopBar } from './components/TopBar';
import { OverviewModule } from './modules/OverviewModule';
import { PPIModule } from './modules/PPIModule';
import { CPIModule } from './modules/CPIModule';
import { PMIManufacturingModule } from './modules/PMIManufacturingModule';
import { PMINonManufacturingModule } from './modules/PMINonManufacturingModule';
import { IndustrialModule } from './modules/IndustrialModule';
import { ElectricityModule } from './modules/ElectricityModule';
import { FXReserveModule } from './modules/FXReserveModule';
import { ExportModule } from './modules/ExportModule';
import { ImportModule } from './modules/ImportModule';
import { RetailModule } from './modules/RetailModule';
import { IncomeModule } from './modules/IncomeModule';
import { UnemploymentModule } from './modules/UnemploymentModule';
import { FAIModule } from './modules/FAIModule';
import { RealEstateModule } from './modules/RealEstateModule';
import { SocialFinancingModule } from './modules/SocialFinancingModule';
import { CreditModule } from './modules/CreditModule';
import { PolicyRateModule } from './modules/PolicyRateModule';
import { MoneySupplyModule } from './modules/MoneySupplyModule';
import { DepositModule } from './modules/DepositModule';
import { LayoutDashboard, TrendingUp, Factory, Ship, ShoppingCart, HardHat, Landmark, Droplets } from 'lucide-react';

export interface NavItem {
  id: string;
  label: string;
  icon?: React.ElementType;
  children?: NavItem[];
  badge?: string;
}

export const navItems: NavItem[] = [
  { id: 'overview', label: '数据概览', icon: LayoutDashboard },
  {
    id: 'price', label: '价格指标', icon: TrendingUp,
    children: [
      { id: 'ppi', label: 'PPI' },
      { id: 'cpi', label: 'CPI' },
    ],
  },
  {
    id: 'production', label: '生产指标', icon: Factory,
    children: [
      { id: 'pmi-mfg', label: '制造业PMI' },
      { id: 'pmi-nonmfg', label: '非制造业PMI和财新PMI' },
      { id: 'industrial', label: '工业增加值' },
      { id: 'electricity', label: '社会用电量' },
    ],
  },
  {
    id: 'trade', label: '进出口指标', icon: Ship,
    children: [
      { id: 'fx-reserve', label: '外汇储备' },
      { id: 'export', label: '出口' },
      { id: 'import', label: '进口' },
    ],
  },
  {
    id: 'consumption', label: '消费指标', icon: ShoppingCart,
    children: [
      { id: 'retail', label: '社零增加值' },
      { id: 'income', label: '居民可支配收入' },
      { id: 'unemployment', label: '城镇失业率' },
    ],
  },
  {
    id: 'investment', label: '投资指标', icon: HardHat,
    children: [
      { id: 'fai', label: '固定投资增速' },
      { id: 'realestate', label: '地产数据' },
    ],
  },
  {
    id: 'finance', label: '金融指标', icon: Landmark,
    children: [
      { id: 'social-financing', label: '社融' },
      { id: 'credit', label: '信贷' },
    ],
  },
  {
    id: 'liquidity', label: '流动性指标', icon: Droplets,
    children: [
      { id: 'policy-rate', label: '政策利率' },
      { id: 'money-supply', label: '资金活力' },
      { id: 'deposit', label: '存款' },
    ],
  },
];

interface AppContextType {
  activeModule: string;
  setActiveModule: (id: string) => void;
  sidebarCollapsed: boolean;
  setSidebarCollapsed: (v: boolean) => void;
  dateRange: { start: string; end: string };
  setDateRange: (r: { start: string; end: string }) => void;
}

const AppContext = createContext<AppContextType>({
  activeModule: 'overview',
  setActiveModule: () => {},
  sidebarCollapsed: false,
  setSidebarCollapsed: () => {},
  dateRange: { start: '2024-01', end: '2026-03' },
  setDateRange: () => {},
});

export const useApp = () => useContext(AppContext);

function App() {
  const [activeModule, setActiveModule] = useState('overview');
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [dateRange, setDateRange] = useState({ start: '2024-01', end: '2026-03' });

  const handleSetModule = useCallback((id: string) => {
    setActiveModule(id);
  }, []);

  const renderModule = () => {
    switch (activeModule) {
      case 'overview': return <OverviewModule />;
      case 'ppi': return <PPIModule />;
      case 'cpi': return <CPIModule />;
      case 'pmi-mfg': return <PMIManufacturingModule />;
      case 'pmi-nonmfg': return <PMINonManufacturingModule />;
      case 'industrial': return <IndustrialModule />;
      case 'electricity': return <ElectricityModule />;
      case 'fx-reserve': return <FXReserveModule />;
      case 'export': return <ExportModule />;
      case 'import': return <ImportModule />;
      case 'retail': return <RetailModule />;
      case 'income': return <IncomeModule />;
      case 'unemployment': return <UnemploymentModule />;
      case 'fai': return <FAIModule />;
      case 'realestate': return <RealEstateModule />;
      case 'social-financing': return <SocialFinancingModule />;
      case 'credit': return <CreditModule />;
      case 'policy-rate': return <PolicyRateModule />;
      case 'money-supply': return <MoneySupplyModule />;
      case 'deposit': return <DepositModule />;
      default: return <OverviewModule />;
    }
  };

  return (
    <AppContext.Provider value={{
      activeModule,
      setActiveModule: handleSetModule,
      sidebarCollapsed,
      setSidebarCollapsed,
      dateRange,
      setDateRange,
    }}>
      <div className="flex h-screen w-screen bg-[#0a0e1a] text-[#f1f5f9] overflow-hidden">
        <Sidebar />
        <div className="flex flex-col flex-1 min-w-0">
          <TopBar />
          <main className="flex-1 overflow-y-auto p-4">
            {renderModule()}
          </main>
        </div>
      </div>
    </AppContext.Provider>
  );
}

export default App;
